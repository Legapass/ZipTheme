=== Axeptio Cookies ===
Contributors: axeptio
Requires at least: 4.9
Tags: rgpd, cookies
Tested up to: 5.4
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin is built to handle your website's cookies

== Description ==

The plugin works with a Javascript SDK to manage and handle your website's cookies.

== Documentation ==
1. You must refer to the official documentation. Find it here : <a href="https://developers.axeptio.eu/integration/integration-cms/integration-wordpress">Official documentation</a>