<?php
/**
 * The sidebar containing the main widget area.
 */
if (!is_active_sidebar('motor_sidebar')) {
	return;
}
?>
<aside id="secondary" class="blog-sb">
	<?php if ( is_active_sidebar( 'motor_sidebar' ) ) : ?>
		<div class="blog-sb-widgets">
		<?php motor_content('blog_sidebar'); ?>
		<?php dynamic_sidebar( 'motor_sidebar' ); ?>
		</div>
	<?php endif; ?>
</aside>