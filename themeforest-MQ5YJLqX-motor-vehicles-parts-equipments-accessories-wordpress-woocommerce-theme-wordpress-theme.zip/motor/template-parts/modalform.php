<?php
global $motor_options;

// Modal Form
if (!empty($motor_options['other_modalform'])) : ?>
	<div id="modal-form" class="modal-form">
		<?php echo do_shortcode($motor_options['other_modalform']); ?>
	</div>
<?php endif; ?>

<?php
// Modal Form - Request Product
if ($motor_options['catalog_request'] == 'yes') : ?>
	<div id="request-form" class="modal-form">
		<?php
		if (!empty($motor_options['catalog_requestform'])) {
			echo do_shortcode($motor_options['catalog_requestform']);
		} else {
			esc_html_e('Please set a form', 'motor');
		}
		?>
	</div>
<?php endif; ?>