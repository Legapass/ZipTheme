<?php
// Defaults
if (empty($layout)) {
    $layout = 'normal';
}
if (empty($columns)) {
    $columns = '3';
}
if (!isset($img_ratio)) {
    $img_ratio = 80;
}
if (empty($show_title)) {
    $show_title = '';
}
if (empty($show_category)) {
    $show_category = '';
}
if (empty($show_buttons)) {
    $show_buttons = '';
}
if (empty($image_size)) {
    $image_size = 'large';
}
if (empty($content_position)) {
    $content_position = 'middle';
}


$post_class = array('projects-i', 'projects-i-cp-'.$content_position);

$post_class[] = 'pl-15';
$post_class[] = 'pr-15';

$category = get_the_terms(get_the_ID(), 'motor_project_category');
if (!empty($category)) {
    foreach ($category as $cat) {
        $post_class[] = $cat->slug;
    }
}

if (!empty($align)) {
    $post_class[] = 'projects-i-'.$align;
}

/*if ($layout === 'packery') {
    $item_index = $index + (($page_num - 1) * $posts_per_page) + 1;
    $columns_default = $columns;
    $img_ratio_default = $img_ratio;
    $packery_column = motor_packery_column($item_index, $layout_packery_items, $columns);
    $columns = $packery_column['width'];
    $img_ratio = $img_ratio * $packery_column['height'];
}*/

if ($layout === 'packery') {
    $item_index = $index + (($page_num - 1) * $posts_per_page) + 1;
    //$columns_default = $columns;
    $img_ratio_default = $img_ratio;
    $packery_column = motor_packery_column($item_index, $layout_packery_items, $columns);
    $img_ratio = $img_ratio * $packery_column['height'];
    switch ($packery_column['width']) {
        case '1':
            $post_class[] = 'col-sm-6 col-xl-1'; break;
        case '2':
            $post_class[] = 'col-sm-6 col-xl-2'; break;
        case '3':
            $post_class[] = 'col-sm-6 col-xl-3'; break;
        case '4':
            $post_class[] = 'col-sm-6 col-xl-4'; break;
        case '5':
            $post_class[] = 'col-sm-6 col-xl-5'; break;
        case '6':
            $post_class[] = 'col-sm-6 col-xl-6'; break;
        case '7':
            $post_class[] = 'col-sm-6 col-xl-7'; break;
        case '8':
            $post_class[] = 'col-sm-6 col-xl-8'; break;
        case '9':
            $post_class[] = 'col-sm-6 col-xl-9'; break;
        case '10':
            $post_class[] = 'col-sm-6 col-xl-10'; break;
        case '11':
            $post_class[] = 'col-sm-6 col-xl-11'; break;
        case '12':
            $post_class[] = 'col-sm-12 full-width'; break;
        default:
            $post_class[] = 'col-sm-6 col-xl-3'; break;
    }
} else {
switch ($columns) {
    case '1':
        $post_class[] = 'col-sm-12 full-width';
        break;
    case '2':
        $post_class[] = 'col-sm-6';
        break;
    case '3':
        $post_class[] = 'col-sm-6 col-xl-4';
        break;
    case '4':
        $post_class[] = 'col-sm-6 col-lg-4 col-xl-3';
        break;
    case '6':
        $post_class[] = 'col-sm-6 col-md-4 col-lg-3 col-xl-2';
        break;
    case 'metro':
        $item_index = $index + (($page_num - 1) * $posts_per_page);
        $metro_column = motor_metro_column($item_index, $layout_metro_row);
        switch ($metro_column['column']) {
            case '1':
                $post_class[] = 'col-sm-6 col-xl-1'; break;
            case '2':
                $post_class[] = 'col-sm-6 col-xl-2'; break;
            case '3':
                $post_class[] = 'col-sm-6 col-xl-3'; break;
            case '4':
                $post_class[] = 'col-sm-6 col-xl-4'; break;
            case '5':
                $post_class[] = 'col-sm-6 col-xl-5'; break;
            case '6':
                $post_class[] = 'col-sm-6 col-xl-6'; break;
            case '7':
                $post_class[] = 'col-sm-6 col-xl-7'; break;
            case '8':
                $post_class[] = 'col-sm-6 col-xl-8'; break;
            case '9':
                $post_class[] = 'col-sm-6 col-xl-9'; break;
            case '10':
                $post_class[] = 'col-sm-6 col-xl-10'; break;
            case '11':
                $post_class[] = 'col-sm-6 col-xl-11'; break;
            case '12':
                $post_class[] = 'col-sm-12 full-width'; break;
            default:
                $post_class[] = 'col-sm-6 col-xl-3'; break;
        }
        break;
}
}

$img_src = array();
if (has_post_thumbnail()) {
    $img_src = wp_get_attachment_image_src(get_post_thumbnail_id(), $image_size);
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class($post_class); ?>>
<div class="projects-i-inner">

    <?php if (!empty($img_src[0])) : ?>
        <a href="<?php the_permalink(); ?>" class="projects-i-img" style="background-image: url(<?php echo esc_url($img_src[0]); ?>);<?php if (!empty($metro_column['height'])) { echo 'height:'.intval($metro_column['height']).'px;'; } ?>">
            <div class="img-ratio img-ratio-<?php echo intval($img_ratio); ?>"></div>
            <img src="<?php echo esc_url($img_src[0]); ?>" alt="<?php the_title(); ?>">
        </a>
    <?php else:
        if (empty($img_ratio)) {
            $img_ratio = 60;
        }
        ?>
        <a href="<?php the_permalink(); ?>" class="projects-i-img"<?php if (!empty($metro_column['height'])) { echo 'style="height:'.intval($metro_column['height']).'px;"'; } ?>>
            <div class="img-ratio img-ratio-<?php echo intval($img_ratio); ?>"></div>
        </a>
    <?php endif; ?>

    <div class="projects-i-cont">
        <a class="projects-i-cont-link" href="<?php the_permalink(); ?>"></a>

        <?php if ($show_category == 'show') : ?>
            <?php if (get_post_type() == 'motor_project') : ?>
                <?php if (!empty($category)) : ?>
                    <div class="projects-i-cat">
                        <?php foreach ($category as $key=>$cat) : ?>
                            <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"><?php echo esc_attr($cat->name); ?></a><?php echo ($key+1<count($category)) ? ' / ' : ''; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="projects-i-cat"><span><?php echo get_post_type(); ?></span></div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($show_title == 'show') : ?>
        <h3 class="projects-i-ttl">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        <?php endif; ?>

        <?php if ($show_buttons == 'show') : ?>
        <div class="projects-i-btns">
            <a href="#" data-project-qview="<?php the_ID(); ?>" title="<?php esc_attr_e('Quick View', 'motor'); ?>"><?php if (!empty($settings['content_style_buttons_qview']['url'])) { echo motor_get_contents($settings['content_style_buttons_qview']['url']); } else { echo '.<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" width="512px" height="512px"><path d="M504.508,474.582l-163.48-163.48c26.405-32.888,42.214-74.647,42.214-120.102c0-106.033-85.967-192-192-192    s-192,85.967-192,192s85.967,192,192,192c45.207,0,86.759-15.635,119.563-41.78l163.532,163.532c8.331,8.331,21.839,8.331,30.17,0    C512.84,496.42,512.84,482.913,504.508,474.582z M41.91,191c0-82.469,66.865-149.333,149.333-149.333S340.577,108.531,340.577,191    c0,41.354-16.816,78.783-43.98,105.826c-0.002,0.002-0.005,0.004-0.007,0.007c-0.001,0.001-0.003,0.003-0.004,0.005    c-27.005,26.879-64.234,43.496-105.342,43.496C108.775,340.333,41.91,273.469,41.91,191z" fill="#FFFFFF"/></svg>.'; } ?></a>
            <a href="<?php the_permalink(); ?>" title="<?php esc_attr_e('Show Details', 'motor'); ?>"><?php if (!empty($settings['content_style_buttons_link']['url'])) { echo motor_get_contents($settings['content_style_buttons_link']['url']); } else { echo '.<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 511.997 511.997" style="enable-background:new 0 0 511.997 511.997;" xml:space="preserve" width="512px" height="512px"><path d="M211.26,389.24l-60.331,60.331c-25.012,25.012-65.517,25.012-90.508,0.005c-24.996-24.996-24.996-65.505-0.005-90.496     l120.683-120.683c24.991-24.992,65.5-24.992,90.491,0c8.331,8.331,21.839,8.331,30.17,0c8.331-8.331,8.331-21.839,0-30.17     c-41.654-41.654-109.177-41.654-150.831,0L30.247,328.909c-41.654,41.654-41.654,109.177,0,150.831     c41.649,41.676,109.177,41.676,150.853,0l60.331-60.331c8.331-8.331,8.331-21.839,0-30.17S219.591,380.909,211.26,389.24z" fill="#FFFFFF"/><path d="M479.751,30.24c-41.654-41.654-109.199-41.654-150.853,0l-72.384,72.384c-8.331,8.331-8.331,21.839,0,30.17     c8.331,8.331,21.839,8.331,30.17,0l72.384-72.384c24.991-24.992,65.521-24.992,90.513,0c24.991,24.991,24.991,65.5,0,90.491     L316.845,283.638c-24.992,24.992-65.5,24.992-90.491,0c-8.331-8.331-21.839-8.331-30.17,0s-8.331,21.839,0,30.17     c41.654,41.654,109.177,41.654,150.831,0l132.736-132.736C521.405,139.418,521.405,71.894,479.751,30.24z" fill="#FFFFFF"/></svg>.'; } ?></a>
        </div>
        <?php endif; ?>
    </div>

</div>
</article>
<?php
if ($layout === 'packery') {
    //$columns = $columns_default;
    $img_ratio = $img_ratio_default;
}