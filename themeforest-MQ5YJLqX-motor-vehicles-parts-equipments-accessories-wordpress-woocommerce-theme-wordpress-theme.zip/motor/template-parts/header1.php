<div id="masthead" class="header">

    <a href="#" class="header-menutoggle" id="header-menutoggle"><?php echo esc_html__('Menu', 'motor'); ?></a>

    <div class="header-info">

        <?php if ( class_exists( 'WooCommerce' ) && in_array('profile', $motor_options['header_show']) ) : ?>
            <div class="header-personal">
                <?php if (is_user_logged_in()) : ?>
                    <a class="header-gopersonal" href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 13.5C1 10.5309 3.61521 8 7 8C10.3848 8 13 10.5309 13 13.5V15H1V13.5Z" stroke="white" stroke-width="2"/><circle cx="7" cy="4" r="3" stroke="white" stroke-width="2"/></svg></a>
                    <ul>

                        <?php if (!empty($motor_options['compare']['id']) && defined( 'WCCM_VERISON' ) && in_array('compare', $motor_options['header_show'])) : ?>
                            <li>
                                <a href="<?php echo esc_url($motor_options['compare']['url']); ?>"><?php echo esc_html__('Compare list', 'motor'); ?> <span id="h-personal-compare-count"><?php echo intval($motor_options['compare']['count']); ?></span></a>
                            </li>
                        <?php endif; ?>

                        <?php if (!empty($motor_options['wishlist']['id']) && class_exists( 'YITH_WCWL' ) && in_array('wishlist', $motor_options['header_show'])) : ?>
                            <li>
                                <a href="<?php echo esc_url($motor_options['wishlist']['url']); ?>"><?php echo esc_html__('Wishlist', 'motor'); ?> <span id="h-personal-wishlist-count"><?php $wishlist_count = YITH_WCWL()->count_products(); echo intval($wishlist_count); ?></span></a>
                            </li>
                        <?php endif; ?>

                        <?php if (in_array('cart', $motor_options['header_show'])) : ?>
                            <li class="header-personal-cart">
                                <a href="<?php echo esc_url(wc_get_cart_url()); ?>"><?php echo esc_html__('Shopping Cart', 'motor'); ?> <span><?php echo WC()->cart->get_cart_contents_count()?></span></a>
                            </li>
                            <li class="header-order">
                                <a href="<?php echo esc_url(wc_get_checkout_url()); ?>"><?php echo esc_html__('Checkout', 'motor'); ?></a>
                            </li>
                        <?php endif; ?>

                        <li>
                            <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><?php echo esc_html__('My Account', 'motor'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url(wc_customer_edit_account_url()); ?>"><?php echo esc_html__('Settings', 'motor'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url( wc_get_endpoint_url( 'customer-logout', '', wc_get_page_permalink( 'myaccount' ) ) ); ?>"><?php echo esc_html__('Log out', 'motor'); ?></a>
                        </li>
                    </ul>
                <?php else : ?>
                    <a class="header-gopersonal" href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 13.5C1 10.5309 3.61521 8 7 8C10.3848 8 13 10.5309 13 13.5V15H1V13.5Z" stroke="white" stroke-width="2"/><circle cx="7" cy="4" r="3" stroke="white" stroke-width="2"/></svg></a>
                    <ul>
                        <li>
                            <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><?php esc_html_e('Login / Register','motor'); ?></a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (class_exists( 'woocommerce' ) && in_array('cart', $motor_options['header_show'])) : ?>
            <div class="header-cart">
                <?php
                motor_cart_link();
                the_widget( 'WC_Widget_Cart', 'title=' );
                ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($motor_options['compare']['id']) && defined( 'WCCM_VERISON' ) && in_array('compare', $motor_options['header_show'])) : ?>
            <a title="<?php esc_html_e('Compare', 'motor'); ?>" href="<?php echo esc_url($motor_options['compare']['url']); ?>" class="header-compare"><svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L1 7C1 5.34315 2.34253 4 3.99939 4C7.21892 4 11.891 4 12.0001 4M12.0001 4L11.0001 3V5L12.0001 4Z" stroke="#858DAA" stroke-width="2"/><path d="M15 8L15 11C15 12.6569 13.6575 14 12.0006 14C8.78108 14 4.10897 14 3.99995 14M3.99995 14L4.99995 15L4.99995 13L3.99995 14Z" stroke="#858DAA" stroke-width="2"/></svg><?php if (!empty($motor_options['compare']['count'])) : ?><span id="h-compare-count"><?php echo intval($motor_options['compare']['count']); ?></span><?php endif; ?></a>
        <?php endif; ?>

        <?php if (!empty($motor_options['wishlist']['id']) && class_exists( 'YITH_WCWL' ) && in_array('wishlist', $motor_options['header_show'])) : ?>
            <a title="<?php esc_html_e('Wishlist', 'motor'); ?>" href="<?php echo esc_url($motor_options['wishlist']['url']); ?>" class="header-favorites"><svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.8123 2.0309L15.8185 2.03727L15.8248 2.04353C16.6108 2.8226 17 3.75901 17 4.91667C17 6.04054 16.615 6.96491 15.8248 7.74814L15.8211 7.75183L9 14.5846L2.17886 7.75183L2.17887 7.75182L2.17516 7.74814C1.38504 6.96491 1 6.04054 1 4.91667C1 3.75901 1.38924 2.8226 2.17516 2.04353L2.18147 2.03727L2.18767 2.0309C2.86484 1.33534 3.65933 1 4.62981 1C5.63619 1 6.44292 1.34034 7.11521 2.0309L7.11514 2.03097L7.12511 2.04093L8.29338 3.20759L8.98727 3.90053L9.69364 3.22032L10.9052 2.05365L10.9168 2.04246L10.9281 2.0309C11.6052 1.33534 12.3997 1 13.3702 1C14.3407 1 15.1352 1.33534 15.8123 2.0309Z" stroke="#858DAA" stroke-width="2"/></svg><?php $wishlist_count = YITH_WCWL()->count_products(); if (!empty($wishlist_count)) : ?><span id="h-wishlist-count"><?php echo intval($wishlist_count); ?></span><?php endif; ?></a>
        <?php endif; ?>

        <?php
        // Search Form
        if ($motor_options['header_search'] !== 'hide') : ?>
            <a href="#" class="header-searchbtn" id="header-searchbtn"><svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 10L15.5 15.5" stroke="white" stroke-width="2"/><circle cx="6.5" cy="6.5" r="5.5" stroke="white" stroke-width="2"/></svg></a>
            <?php get_search_form(); ?>
        <?php endif; ?>

    </div>

    <p class="header-logo">
        <?php if (!empty($motor_options['header_logo'])) : ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_attr($motor_options['header_logo']); ?>" alt="<?php bloginfo('name'); ?>"></a><?php else: ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="<?php bloginfo('name'); ?>"></a><?php endif; ?>
    </p>

    <?php
    wp_nav_menu( array(
        'theme_location' => 'rw-top-menu',
        'container' => 'nav',
        'container_class' => '',
        'container_id' => 'top-menu',
        'items_wrap' => '<ul>%3$s</ul>',
        'walker' => new Motor_Mega_Menu_Walker(),
    ) );
    ?>

</div>