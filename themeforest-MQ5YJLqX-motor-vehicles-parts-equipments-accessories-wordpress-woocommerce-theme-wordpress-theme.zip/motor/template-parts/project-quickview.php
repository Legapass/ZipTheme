<?php
if (!defined('ABSPATH')) exit;

global $motor_options;
$motor_options['blog_share'] = get_theme_mod('other_share', array('facebook', 'twitter', 'vk', 'pinterest', 'gplus', 'linkedin', 'tumblr'));
$motor_options['projects_width'] = 'container';
$motor_options['projects_type'] = 'list';
?>
<div class="project-quickview-modal" id="quickview-modal">

<?php if (have_posts()) : ?>
<?php while ( have_posts() ) : the_post();

    $post_object = get_post( get_the_ID() );
    setup_postdata( $GLOBALS['post'] =& $post_object );

    motor_title_block_render('normal-project');

    $is_elementor = get_post_meta(get_the_ID(), '_elementor_edit_mode', true);
    if (!empty($is_elementor) && $is_elementor == 'builder') {
        $post_width = 'full';
    } else {
        $post_width = 'container';
    }
    ?>

    <?php
    if ($post_width == 'full') {
        ?>
        <section id="<?php echo get_the_ID(); ?>" <?php post_class(array('site-content', 'project-item', 'maincont', 'page-styling', 'page-full')); ?>>
        <?php
    } else {
        ?>
        <article id="<?php echo get_the_ID(); ?>" <?php post_class(array('site-content', 'container', 'maincont', 'project-item', 'page-styling')); ?>>
        <?php
    }

    $info = array();
    $info_meta = get_post_meta(get_the_ID(), 'motor_project_info', true);
    if (!empty($info_meta['value'])) {
        foreach ($info_meta['value'] as $key=>$value) {
            $info[$key]['value'] = $value;
            if (!empty($info_meta['label'][$key])) {
                $info[$key]['label'] = $info_meta['label'][$key];
            } else {
                $info[$key]['label'] = '';
            }
        }
    }

    if (!empty($info) && !empty($info['0']['value']) && !empty($info['0']['label'])) {
        if ($post_width == 'full') {
            echo '<div class="container">';
        }
        ?>
        <ul class="project-item-info">
            <?php
            foreach($info as $info_item) {
                ?>
                <li>
                    <b><?php echo esc_html($info_item['label']); ?></b>
                    <span><?php echo esc_html($info_item['value']); ?></span>
                </li>
                <?php
            }
            ?>
        </ul>
        <?php
        if ($post_width == 'full') {
            echo '</div>';
        }
    }

    if (!empty($is_elementor) && $is_elementor == 'builder') {
        echo \Elementor\Plugin::$instance->frontend->get_builder_content( get_the_ID(), true );
    } else {
        ?>
        <div class="page-cont">
            <?php
            the_content();

            echo '<div class="project-item-share">';
            if (!empty($motor_options['blog_share'])) {
                get_template_part('template-parts/share');
            }
            echo '</div>';
            ?>
        </div>
        <?php
    }


    if ($post_width == 'full') {
        ?>
        </section>
        <?php
    } else {
        ?>
        </article>
        <?php
    }
    ?>

    <?php
    get_template_part('template-parts/project-gallery');
    ?>

<?php endwhile; ?>
<?php endif; wp_reset_postdata(); ?>

</div>
