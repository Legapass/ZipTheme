<?php
global $motor_options;
$gallery = get_post_meta(get_the_ID(), 'motor_project_gallery', true);

if (has_post_thumbnail() || !empty($gallery)) {

    if ($motor_options['projects_type'] == 'carousel' || $motor_options['projects_type'] == 'slider') {

        $img_size = 'motor_1920x1400';
        $img_size_full = 'motor_1920x1400';
        if ($motor_options['projects_width'] === 'container') {
            $img_size = 'motor_1170x1400';
        }
        ?>
        <div class="<?php if ($motor_options['projects_width'] === 'container') { echo 'container '; } echo 'project-pg-img-position-'.$motor_options['projects_position'].' '; ?>project-pg-carousel-wrap">

            <div id="<?php if ($motor_options['projects_type'] === 'slider') { echo 'project-pg-slider'; } else { echo 'product-pg-carousel'; } ?>" class="swiper-container project-pg-carousel<?php if ($motor_options['projects_type'] === 'slider') { echo ' project-pg-slider'; } ?><?php if ($motor_options['projects_width_img'] == 'full') { echo ' project-pg-img-full'; } ?>">
                <div class="swiper-wrapper">
                    <?php
                    if (has_post_thumbnail()) :
                        $img_src = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size);
                        $img_src_full = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size_full);
                        ?>
                        <div class="swiper-slide">
                            <a data-fancybox-group="project" class="fancy-img" href="<?php echo esc_attr($img_src_full[0]); ?>">
                                <img src="<?php echo esc_attr($img_src[0]); ?>" alt="<?php the_title(); ?>">
                            </a>
                        </div>
                    <?php
                    endif;

                    if (!empty($gallery)) {
                        foreach ($gallery as $gallery_item) {
                            if (!empty($gallery_item)) {
                                $img_src = wp_get_attachment_image_src($gallery_item, $img_size);
                                $img_src_full = wp_get_attachment_image_src($gallery_item, $img_size_full);
                                ?>
                                <div class="swiper-slide">
                                    <a data-fancybox-group="project" class="fancy-img" href="<?php echo esc_attr($img_src_full[0]); ?>">
                                        <img src="<?php echo esc_attr($img_src[0]); ?>" alt="<?php the_title(); ?>">
                                    </a>
                                </div>
                                <?php
                            }
                        }
                    }
                    ?>
                </div>
            </div>

            <div id="<?php if ($motor_options['projects_type'] === 'slider') { echo 'project-pg-slider-thumbs'; } else { echo 'product-pg-carousel-thumbs'; } ?>" class="swiper-container project-pg-carousel-thumbs<?php if ($motor_options['projects_type'] === 'slider') { echo ' project-pg-slider-thumbs'; } ?>">
                <div class="swiper-wrapper">
                    <?php
                    if (has_post_thumbnail()) {
                        $img_src = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size);
                        ?>
                        <div class="swiper-slide" style="background: url(<?php echo esc_attr($img_src[0]); ?>);"></div>
                        <?php
                    }

                    if (!empty($gallery)) {
                        foreach ($gallery as $gallery_item) {
                            if (!empty($gallery_item)) {
                                $img_src = wp_get_attachment_image_src($gallery_item, $img_size);
                                ?>
                                <div class="swiper-slide" style="background: url(<?php echo esc_attr($img_src[0]); ?>);"></div>
                                <?php
                            }
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php

    } else {

        $img_size = 'motor_1920x1400';
        $img_size_full = 'motor_1920x1400';
        if ($motor_options['projects_width'] === 'container') {
            $img_size = 'motor_1170x1400';
            echo '<div class="container project-pg-img-position-'.$motor_options['projects_position'].' project-item-gallery project-item-gallery-'.$motor_options['projects_type'].(($motor_options['projects_width_img'] == 'full' && $motor_options['projects_type'] == 'list') ? ' project-pg-img-full' : '').'">';
        } else {
            echo '<div class="project-pg-img-position-'.$motor_options['projects_position'].' project-item-gallery project-item-gallery-'.$motor_options['projects_type'].(($motor_options['projects_width_img'] == 'full' && $motor_options['projects_type'] == 'list') ? ' project-pg-img-full' : '').'">';
        }

        if ($motor_options['projects_type'] == 'masonry') {
            echo '<div class="posts-items-masonry">';
        }

        if (has_post_thumbnail()) :
            $img_src = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size);
            $img_src_full = wp_get_attachment_image_src(get_post_thumbnail_id(), $img_size_full);
            ?>
            <div class="project-item-img">
                <a data-fancybox-group="project" class="fancy-img" href="<?php echo esc_attr($img_src_full[0]); ?>">
                    <img src="<?php echo esc_attr($img_src[0]); ?>" alt="<?php the_title(); ?>">
                </a>
            </div>
        <?php
        endif;
        if (!empty($gallery)) {
            foreach ($gallery as $gallery_item) {
                if (!empty($gallery_item)) {
                    $img_src = wp_get_attachment_image_src($gallery_item, $img_size);
                    $img_src_full = wp_get_attachment_image_src($gallery_item, $img_size_full);
                    ?>
                    <div class="project-item-img">
                        <a data-fancybox-group="project" class="fancy-img" href="<?php echo esc_attr($img_src_full[0]); ?>">
                            <img src="<?php echo esc_attr($img_src[0]); ?>" alt="<?php the_title(); ?>">
                        </a>
                    </div>
                    <?php
                }
            }
        }

        if ($motor_options['projects_type'] == 'masonry') {
            echo '</div>';
        }

        echo '</div>';

    }
}
