<?php
if (empty($image_size)) {
	$image_size = 'medium';
}
if (empty($show_excerpt)) {
	$show_excerpt = 'show';
}
if (empty($show_thumbnail)) {
	$show_thumbnail = 'show';
}

if (!empty($columns)) {
	$post_class = array('posts-i');

	$category = get_the_terms(get_the_ID(), 'category');
	if (!empty($category)) {
		foreach ($category as $cat) {
			$post_class[] = $cat->slug;
		}
	}

	if (!empty($column_gap)) {
		$post_class[] = 'pl-'.intval($column_gap);
		$post_class[] = 'pr-'.intval($column_gap);
	}
	if (!empty($row_gap)) {
		$post_class[] = 'mb-'.intval($row_gap);
	}
	switch ($columns) {
		case '1':
			$post_class[] = 'col-sm-12 full-width';
			if (empty($image_size)) { $image_size = 'large'; }
			break;
		case '2':
			$post_class[] = 'col-sm-6';
			if (empty($image_size)) { $image_size = 'medium_large'; }
			break;
		case '3':
			$post_class[] = 'col-sm-6 col-xl-4';
			if (empty($image_size)) { $image_size = 'medium'; }
			break;
		case '4':
			$post_class[] = 'col-sm-6 col-lg-4 col-xl-3';
			if (empty($image_size)) { $image_size = 'medium'; }
			break;
		case '6':
			$post_class[] = 'col-sm-6 col-md-4 col-lg-3 col-xl-2';
			if (empty($image_size)) { $image_size = 'medium'; }
			break;
		default:
			$post_class[] = 'col-sm-6';
			if (empty($image_size)) { $image_size = 'medium'; }
			break;
	}
} else {
	$post_class = array('blog-grid-i');
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class($post_class); ?>>
	<div class="blog-i">
		<?php if ($show_thumbnail == 'show') : ?>
			<?php if (!empty($blog_slider) && $blog_slider[0]) : ?>
				<div class="blog-slider">
					<ul class="slides">
						<?php foreach ($blog_slider as $blog_slide) :
							$img_src = wp_get_attachment_image_src($blog_slide, $image_size);
							?>
							<?php if (!empty($img_src[0])) : ?>
							<li>
								<a href="<?php the_permalink(); ?>">
									<?php if (!empty($img_src[0])) : ?>
										<img src="<?php echo esc_attr($img_src[0]); ?>" alt="<?php the_title(); ?>">
									<?php endif; ?>
								</a>
							</li>
							<?php endif; ?>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php elseif (!empty($blog_video)) : ?>
				<div class="blog-img">
					<?php echo wp_oembed_get($blog_video); ?>
				</div>
			<?php elseif (has_post_thumbnail()) : ?>
				<a href="<?php the_permalink(); ?>" class="blog-img">
					<?php the_post_thumbnail('medium'); ?>
				</a>
			<?php endif; ?>
		<?php endif; ?>
		<p class="blog-info">
			<?php
			if (!empty($category)) {
				foreach ($category as $key=>$categ) {
					echo '<a href="'.esc_url(get_term_link($categ->term_id)).'">'.esc_attr($categ->name).'</a>';
					echo ($key+1<count($category)) ? ', ' : '';
				}
			}
			?>
			<time datetime="<?php echo get_the_date('Y-m-d H:i'); ?>"><?php echo get_the_date(); ?></time>
		</p>
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<?php if ($show_excerpt == 'show') : ?>
		<p><?php echo get_the_excerpt(); ?> <a href="<?php the_permalink(); ?>"><?php echo esc_html__('read more', 'motor'); ?></a></p>
		<?php endif; ?>
	</div>
</article>