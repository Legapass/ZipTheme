<?php
global $motor_options;
get_template_part('inc/get-options');
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_site_icon(); ?>
<?php wp_head(); ?>
</head>
<body <?php
$body_class = '';
if (!empty($motor_options['header_sticky']) && $motor_options['header_sticky']) {
	$body_class = 'header-sticky';
}
if (empty($_GET['elementor-preview']) && !empty($motor_options['other_preloader']) && $motor_options['other_preloader']) {
    $body_class .= ' site-preloader-show';
}
body_class($body_class);
?>>

<?php if (empty($_GET['elementor-preview']) && !empty($motor_options['other_preloader']) && $motor_options['other_preloader']) : ?>
<div class="site-preloader" id="site-preloader"><div class="site-preloader-spinner"></div><div class="site-preloader-skip" onclick="jQuery(this).parent().remove(); jQuery('body').removeClass('site-preloader-show');"><?php esc_html_e('Skip Preloader', 'motor'); ?></div></div>
<?php endif; ?>

<div id="page" class="site">


<?php motor_header(); ?>

	
<?php
/*if (!empty($motor_options['header_before'])) {
	$header_before = $motor_options['header_before'];
	if (function_exists('icl_object_id')) {
		$header_before = icl_object_id($motor_options['header_before'], 'page', false, ICL_LANGUAGE_CODE);
	}
	$content = get_post_field('post_content', $header_before);
	if (!empty($content)) {
		echo '<div class="page-styling site-header-before">'.do_shortcode( $content ).'</div>';
	}
}*/
?>


<?php
$header_precreated = $motor_options['header_precreated'];
if (is_page()) {
    $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model(get_the_ID());
    $header_precreated = $page_settings->get_settings('page_header_precreated');

    if ($header_precreated == 'default') {
    	$header_precreated = $motor_options['header_precreated'];
    }
}
if ($header_precreated == 'header-1') {
	include(locate_template('template-parts/header1.php'));
}
?>


<?php
/*if (!empty($motor_options['header_after'])) {
	$header_after = $motor_options['header_after'];
	if (function_exists('icl_object_id')) {
		$header_after = icl_object_id($motor_options['header_after'], 'page', false, ICL_LANGUAGE_CODE);
	}
	$content = get_post_field('post_content', $header_after);
	if (!empty($content)) {
		echo '<div class="page-styling site-header-before">'.do_shortcode( $content ).'</div>';
	}
}*/
?>


<div id="content" class="site-content">