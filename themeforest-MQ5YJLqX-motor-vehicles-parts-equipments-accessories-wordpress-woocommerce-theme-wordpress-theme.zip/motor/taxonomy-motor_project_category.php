<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();

motor_title_block_render();
?>

<section class="site-content container">
    <?php
    if (taxonomy_exists('motor_project_category')) {
        $terms = get_terms( array(
            'taxonomy' => 'motor_project_category',
        ) );
        if( !empty($terms)) {
            ?>
            <ul class="posts-items-filter">
                <?php /*<li class="active"><a href="<?php echo get_permalink( get_option( 'page_for_posts' ) ); ?>"><?php esc_html_e('All', 'motor-theme-plugin'); ?></a></li>*/ ?>
                <?php
                foreach( $terms as $term ){
                    echo "<li ".(!empty($wp_query->query['motor_project_category']) && $wp_query->query['motor_project_category'] == $term->slug ? 'class="active"' : '')."><a href='".esc_url(get_category_link($term->term_id))."'>".esc_attr($term->name)."</a></li>";
                }
                ?>
            </ul>
            <?php
        }
    }
    ?>
    <div class="row projects-items ml-15-m mr-15-m projects-cont-align-center">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) : the_post();

            get_template_part('template-parts/projects-item');

        endwhile;
    else:
        echo '<p class="pl-15 pr-15">'.esc_html__('Posts not exists', 'motor').'</p>';
    endif;
    ?>
    </div>
    <?php
    $paginate_links = paginate_links( array(
        'base'         => esc_url_raw( str_replace( 999999999, '%#%', remove_query_arg( 'add-to-cart', get_pagenum_link( 999999999, false ) ) ) ),
        'format'       => '',
        'add_args'     => '',
        'current'      => max( 1, get_query_var( 'paged' ) ),
        'total'        => $wp_query->max_num_pages,
        'prev_text'    => '<i class="ion-android-arrow-back"></i> '.esc_html__('Prev', 'motor'),
        'next_text'    => esc_html__('Next', 'motor').' <i class="ion-android-arrow-forward"></i>',
        'type'         => 'list',
        'end_size'     => 1,
        'mid_size'     => 2,
    ) );
    if (!empty($paginate_links)) {
        echo '<div class="page-numbers-wrap">'.$paginate_links.'</div>';
    }
    ?>
</section>

<?php
get_footer();
?>