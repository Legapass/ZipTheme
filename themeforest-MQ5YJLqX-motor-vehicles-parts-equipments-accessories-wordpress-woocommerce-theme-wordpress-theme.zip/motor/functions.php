<?php
/**
 * Motor functions and definitions.
 */


// Include the class (unless you are using the script as a plugin)
get_template_part('inc/less/wp-less');


if ( ! function_exists( 'motor_setup' ) ) {
	function motor_setup() {

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Loads the theme's translated strings.
		 */
		load_theme_textdomain( 'motor', get_template_directory() . '/languages' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'rw-top-menu' => esc_html__( 'Top Menu', 'motor' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

        // Add support for editor styles.
        add_theme_support( 'editor-styles' );

        // Enqueue editor styles.
        add_editor_style( 'style-editor.css' );

        add_theme_support( 'editor-color-palette', array(
            array(
                'name' => __( 'Motor Primary', 'motor' ),
                'slug' => 'motor-primary',
                'color' => '#ff3100',
            ),
            array(
                'name' => __( 'Motor Title', 'motor' ),
                'slug' => 'motor-title',
                'color' => '#283346',
            ),
            array(
                'name' => __( 'Motor Text', 'motor' ),
                'slug' => 'motor-text',
                'color' => '#868ca7',
            ),
            array(
                'name' => __( 'Pale pink', 'motor' ),
                'slug' => 'pale-pink',
                'color' => 'rgb(247, 141, 167)',
            ),
            array(
                'name' => __( 'Vivid red', 'motor' ),
                'slug' => 'vivid-red',
                'color' => 'rgb(207, 46, 46)',
            ),
            array(
                'name' => __( 'Luminous vivid orange', 'motor' ),
                'slug' => 'luminous-vivid-orange',
                'color' => 'rgb(255, 105, 0)',
            ),
            array(
                'name' => __( 'Luminous vivid amber', 'motor' ),
                'slug' => 'luminous-vivid-amber',
                'color' => 'rgb(252, 185, 0)',
            ),
            array(
                'name' => __( 'Light green cyan', 'motor' ),
                'slug' => 'light-green-cyan',
                'color' => 'rgb(123, 220, 181)',
            ),
            array(
                'name' => __( 'Vivid green cyan', 'motor' ),
                'slug' => 'vivid-green-cyan',
                'color' => 'rgb(0, 208, 132)',
            ),
            array(
                'name' => __( 'Pale cyan blue', 'motor' ),
                'slug' => 'pale-cyan-blue',
                'color' => 'rgb(142, 209, 252)',
            ),
            array(
                'name' => __( 'Vivid cyan blue', 'motor' ),
                'slug' => 'vivid-cyan-blue',
                'color' => 'rgb(6, 147, 227)',
            ),
            array(
                'name' => __( 'Very light gray', 'motor' ),
                'slug' => 'very-light-gray',
                'color' => 'rgb(238, 238, 238)',
            ),
            array(
                'name' => __( 'Cyan bluish gray', 'motor' ),
                'slug' => 'cyan-bluish-gray',
                'color' => 'rgb(171, 184, 195)',
            ),
            array(
                'name' => __( 'Very dark gray', 'motor' ),
                'slug' => 'very-dark-gray',
                'color' => 'rgb(49, 49, 49)',
            ),
        ) );



		// Declare WooCommerce support
		add_theme_support( 'woocommerce' );

		// Add Image Sizes
		//add_image_size( 'motor_gallery', '390', '234', array('center', 'center') );
		//add_image_size( 'motor_blog', '370', '210', array('center', 'center') );
		//add_image_size( 'motor_blog_slider', '370', '210', false );
		//add_image_size( 'motor_200x200', '200', '200', array('center', 'center') );
		add_image_size( 'motor_full', '1920', '1920', false );

	}
}
add_action( 'after_setup_theme', 'motor_setup' );

// Remove Image Sizes
add_action('init', 'motor_remove_image_sizes');
function motor_remove_image_sizes() {
    remove_image_size('shop_single');
    remove_image_size('shop_catalog');
    remove_image_size('shop_thumbnail');
    remove_image_size('woocommerce_gallery_thumbnail');
    remove_image_size('dgwt-wcas-product-suggestion');
    //remove_image_size('post-thumbnail');
}



/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function motor_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'motor_content_width', 1200 );
}
add_action( 'after_setup_theme', 'motor_content_width', 0 );


// Register widget area
add_action( 'widgets_init', 'motor_widgets_init' );
function motor_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Blog Sidebar', 'motor' ),
		'id'            => 'motor_sidebar',
		'before_widget' => '<div class="blog-sb-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widgettitle">',
		'after_title'   => '</h3>'
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Shop Sidebar', 'motor' ),
		'id'            => 'motor_sidebar_shop',
		'before_widget' => '<div class="blog-sb-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widgettitle">',
		'after_title'   => '</h3>'
	) );
}




/**
 * Enqueue scripts and styles.
 */
function motor_scripts_styles() {

	// enqueue a .less stylesheet
	if (isset($_GET['vc_editable']) && $_GET['vc_editable']) {
		wp_enqueue_style( 'motor-less-style', get_template_directory_uri(). '/wp-less-cache/motor-less.css' );
	} else {
		wp_enqueue_style( 'motor-less', get_template_directory_uri(). '/css/styles.less' );
	}
	//wp_enqueue_style( 'motor-elementor-style', get_template_directory_uri(). '/css/plugins/elementor-style.css', array('elementor') );
	// Enqueue a styles
	wp_enqueue_style( 'motor-style', get_stylesheet_uri() );

	// Enqueue scripts
	wp_enqueue_script( 'jquery_plugins', get_template_directory_uri().'/js/jquery_plugins.js', array( 'jquery' ), null, true);
	wp_deregister_script('wccm-compare');
	if (defined('WCCM_VERISON')) {
		wp_register_script( 'wccm-compare', get_template_directory_uri().'/js/compare.js', array( 'jquery' ), WCCM_VERISON );
	}
	wp_enqueue_script( 'wccm-compare', get_template_directory_uri().'/js/compare.js', array( 'jquery' ), null, true);
	wp_enqueue_script( 'motor-main', get_template_directory_uri().'/js/main.js', array( 'jquery' ), null, true);
	wp_localize_script('motor-main', 'motor_ajax_var', array(
		'url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('ajaxnonce')
	));

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}
add_action( 'wp_enqueue_scripts', 'motor_scripts_styles' );

function motor_scripts_styles_plugins() {
	wp_enqueue_style( 'motor-elementor-style', get_template_directory_uri(). '/css/plugins/elementor-style.css', array('elementor-frontend') );
}
add_action( 'wp_enqueue_scripts', 'motor_scripts_styles_plugins', 10 );



/**
 * Set list of post types where VC editor is enabled.
 */
function detect_plugin_activation(  $plugin, $network_activation ) {
    if ($plugin == 'js_composer/js_composer.php') {
		if (function_exists( 'vc_is_as_theme' )) {
			$vc_editor_post_types = vc_editor_post_types();
			if (!in_array('product', $vc_editor_post_types)) {
				$vc_editor_post_types[] = 'product';
				//vc_set_default_editor_post_types( $vc_editor_post_types );
				vc_editor_set_post_types( $vc_editor_post_types );
			}
		}
    }
    if ($plugin == 'woocommerce/woocommerce.php') {
		if (function_exists( 'vc_is_as_theme' )) {
			$vc_editor_post_types = vc_editor_post_types();
			if (!in_array('product', $vc_editor_post_types)) {
				$vc_editor_post_types[] = 'product';
				//vc_set_default_editor_post_types( $vc_editor_post_types );
				vc_editor_set_post_types( $vc_editor_post_types );
			}
		}
    }
}
add_action( 'activated_plugin', 'detect_plugin_activation', 10, 2 );


// Theme Custom Fields
get_template_part('inc/theme-fields');

// Theme Functions
get_template_part('inc/theme-functions');

// WooCommerce Functions
get_template_part('inc/woocommerce');

// TGM Plugins
get_template_part('inc/tgm');

// Demo Import
get_template_part('framework-customizations/theme/hooks');

// Kirki
if ( class_exists( 'Kirki' ) ) {
	// Load the Kirki Fallback class
    get_template_part('inc/kirki-fallback');
	// Customizer additions.
    get_template_part('inc/customizer');
}

// VC Shortcodes
if ( function_exists( 'vc_is_as_theme' ) ) {
	get_template_part('inc/shortcodes');
}




add_action('elementor/widgets/widgets_registered', function($widgets_manager)
{
    $widgets_manager->unregister_widget_type('wp-widget-woof_widget');
});


get_template_part('inc/less/less-vars');
