<?php
/**
 * Add to wishlist popup template
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Wishlist
 * @version 2.0.0
 */

if ( ! defined( 'YITH_WCWL' ) ) {
	exit;
} // Exit if accessed directly

$unique_id = mt_rand();
?>

<?php if( $show_exists && $exists ): ?>

	<!-- ALREADY IN A WISHLIST MESSAGE -->
	<div class="yith-wcwl-wishlistexistsbrowse <?php echo ( $exists ) ? 'show' : 'hide' ?>" style="display:<?php echo ( $exists ) ? 'block' : 'none' ?>">
		<span class="feedback"><?php echo $already_in_wishslist_text ?></span>
		<a class="active" href="<?php echo esc_url( $wishlist_url ) ?>"><svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.8123 2.0309L15.8185 2.03727L15.8248 2.04353C16.6108 2.8226 17 3.75901 17 4.91667C17 6.04054 16.615 6.96491 15.8248 7.74814L15.8211 7.75183L9 14.5846L2.17886 7.75183L2.17887 7.75182L2.17516 7.74814C1.38504 6.96491 1 6.04054 1 4.91667C1 3.75901 1.38924 2.8226 2.17516 2.04353L2.18147 2.03727L2.18767 2.0309C2.86484 1.33534 3.65933 1 4.62981 1C5.63619 1 6.44292 1.34034 7.11521 2.0309L7.11514 2.03097L7.12511 2.04093L8.29338 3.20759L8.98727 3.90053L9.69364 3.22032L10.9052 2.05365L10.9168 2.04246L10.9281 2.0309C11.6052 1.33534 12.3997 1 13.3702 1C14.3407 1 15.1352 1.33534 15.8123 2.0309Z" stroke="#858DAA" stroke-width="2"/></svg><span class="feedback"><span><?php echo apply_filters( 'yith-wcwl-browse-wishlist-label', $browse_wishlist_text )?></span></span></a>
	</div>

<?php else: ?>

	<!-- WISHLIST POPUP OPENER -->
	<a href="#add_to_wishlist_popup_<?php echo $product_id ?>_<?php echo $unique_id?>" rel="nofollow" class="<?php echo $link_classes ?> open-pretty-photo" data-rel="prettyPhoto[add_to_wishlist_<?php echo $product_id ?>_<?php echo $unique_id?>]" ><svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.8123 2.0309L15.8185 2.03727L15.8248 2.04353C16.6108 2.8226 17 3.75901 17 4.91667C17 6.04054 16.615 6.96491 15.8248 7.74814L15.8211 7.75183L9 14.5846L2.17886 7.75183L2.17887 7.75182L2.17516 7.74814C1.38504 6.96491 1 6.04054 1 4.91667C1 3.75901 1.38924 2.8226 2.17516 2.04353L2.18147 2.03727L2.18767 2.0309C2.86484 1.33534 3.65933 1 4.62981 1C5.63619 1 6.44292 1.34034 7.11521 2.0309L7.11514 2.03097L7.12511 2.04093L8.29338 3.20759L8.98727 3.90053L9.69364 3.22032L10.9052 2.05365L10.9168 2.04246L10.9281 2.0309C11.6052 1.33534 12.3997 1 13.3702 1C14.3407 1 15.1352 1.33534 15.8123 2.0309Z" stroke="#858DAA" stroke-width="2"/></svg><span class="prod-li-favorites-inner"><span><?php esc_html_e('Add to Wishlist', 'motor'); ?></span></span></a>

	<!-- WISHLIST POPUP -->
	<div id="add_to_wishlist_popup_<?php echo $product_id ?>_<?php echo $unique_id?>" class="yith-wcwl-popup">
	    <form class="yith-wcwl-popup-form" method="post" action="<?php echo esc_url( add_query_arg( array( 'add_to_wishlist' => $product_id ) ) )?>">
	        <div class="yith-wcwl-popup-content">

	            <div class="yith-wcwl-first-row">
	                <div class="yith-wcwl-wishlist-select-container">
	                    <h3><?php echo $popup_title ?></h3>
	                    <select name="wishlist_id" class="wishlist-select">
	                        <option value="0" <?php selected( true ) ?> ><?php echo apply_filters( 'yith_wcwl_default_wishlist_name', get_option( 'yith_wcwl_wishlist_title' ) )?></option>
	                        <?php if( ! empty( $lists ) ): ?>
	                            <?php foreach( $lists as $list ):?>
	                                <?php if( ! $list['is_default'] ): ?>
	                                <option value="<?php echo esc_attr( $list['ID'] ) ?>"><?php echo $list['wishlist_name'] ?></option>
	                                <?php endif; ?>
	                            <?php endforeach; ?>
	                        <?php endif; ?>

	                        <option value="new"><?php echo apply_filters( 'yith_wcwl_create_new_list_text', __( 'Create a new list', 'yith-woocommerce-wishlist' ) ) ?></option>
	                    </select>
	                </div>
	                <div class="yith-wcwl-wishlist-thumb">
	                    <?php echo $product_image ?>
	                </div>
	            </div>

	            <div class="yith-wcwl-second-row">
	                <div class="yith-wcwl-popup-new">
	                    <label for="wishlist_name"><?php echo apply_filters( 'yith_wcwl_new_list_title_text', __( 'Wishlist name', 'yith-woocommerce-wishlist' ) ) ?></label>
	                    <input name="wishlist_name" class="wishlist-name" type="text" class="wishlist-name" />
	                </div>
	                <div class="yith-wcwl-visibility">
	                    <select name="wishlist_visibility" class="wishlist-visibility">
	                        <option value="0" class="public-visibility"><?php echo apply_filters( 'yith_wcwl_public_wishlist_visibility', __( 'Public', 'yith-woocommerce-wishlist' ) )?></option>
	                        <option value="1" class="shared-visibility"><?php echo apply_filters( 'yith_wcwl_shared_wishlist_visibility', __( 'Shared', 'yith-woocommerce-wishlist' ) )?></option>
	                        <option value="2" class="private-visibility"><?php echo apply_filters( 'yith_wcwl_private_wishlist_visibility', __( 'Private', 'yith-woocommerce-wishlist' ) )?></option>
	                    </select>
	                </div>
	            </div>
	        </div>

	        <div class="yith-wcwl-popup-footer">
	            <div class="yith-wcwl-popup-button">
	                <img src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ) ?>" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	                <a rel="nofollow" class="wishlist-submit <?php echo $link_popup_classes ?>" data-product-id="<?php echo $product_id ?>" data-product-type="<?php echo $product_type?>">
	                    <?php echo $label_popup ?>
	                </a>
	            </div>
	        </div>
	    </form>
	</div>

<?php endif; ?>