<?php
global $product, $motor_options;
// Extra post classes
if (empty($classes)) {
	$classes = array('sectgl prod-i');
}
if (empty($image_size)) {
	$image_size = 'woocommerce_thumbnail';
}
?>
<article id="post-<?php the_ID(); ?>" <?php wc_product_class( $classes, $product ); ?>>

	<?php
	/**
	 * woocommerce_before_shop_loop_item hook.
	 *
	 * @hooked woocommerce_template_loop_product_link_open - 10
	 */
	do_action( 'woocommerce_before_shop_loop_item' );
	?>

	<div class="prod-i-actions">
		<button class="quick-view prod-i-quick-view" data-id="<?php echo get_the_ID(); ?>"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="5" y="5" width="6" height="6" rx="1" stroke="#858DAA" stroke-width="2"/><path d="M1 9V13C1 14.1046 1.89543 15 3 15H7" stroke="#858DAA" stroke-width="2"/><path d="M15 7L15 3C15 1.89543 14.1046 1 13 1L9 1" stroke="#858DAA" stroke-width="2"/></svg><span class="prod-i-quick-view-inner"><span><?php esc_html_e('Quick View', 'motor'); ?></span></span></button>
        <?php
        if ( class_exists( 'YITH_WCWL' ) ) {
            echo do_shortcode('[yith_wcwl_add_to_wishlist]');
        }
        ?>
        <?php motor_show_compare_btn(); ?>
        <?php if ($motor_options['catalog_grid_btninfo'] == 'yes') : ?>
        <button type="button" class="prod-i-btninfo"><svg width="16" height="14" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1H16M0 1H4M7 7H16M0 7H4M7 13H16M0 13H4" stroke="#858DAA" stroke-width="2"/></svg></button>
        <?php woocommerce_template_single_meta(); ?>
        <?php endif; ?>
	</div>

	<a href="<?php the_permalink(); ?>" class="prod-i-link">
        <p class="prod-i-img<?php if (!empty($img_carousel) && in_array('gallery', $img_carousel)) { echo ' prod-catalog-carousel'; } ?>"><?php
            if (!empty($img_carousel) && in_array('gallery', $img_carousel)) {
                $attachment_ids = $product->get_gallery_image_ids();
                if (has_post_thumbnail()) {
                    $img_src = wp_get_attachment_image_src(get_post_thumbnail_id(), $image_size);
                    echo '<img src="' . esc_url($img_src[0]) . '" alt="' . get_the_title() . '">';
                }
                if (!empty($attachment_ids)) {
                    foreach ($attachment_ids as $attachment_id) {
                        $img_src = wp_get_attachment_image_src($attachment_id, 'woocommerce_thumbnail');
                        echo '<img src="' . esc_url($img_src[0]) . '" alt="' . get_the_title() . '">';
                    }
                }
            } else {
                echo woocommerce_get_product_thumbnail($image_size);
            }
            ?></p>

		<?php
		/**
		 * woocommerce_before_shop_loop_item_title hook.
		 *
		 * @hooked woocommerce_show_product_loop_sale_flash - 10
		 * @hooked woocommerce_template_loop_product_thumbnail - 10
		 */
		do_action( 'woocommerce_before_shop_loop_item_title' );
		?>
		<?php
		/**
		 * woocommerce_shop_loop_item_title hook.
		 *
		 * @hooked woocommerce_template_loop_product_title - 10
		 */
		do_action( 'woocommerce_shop_loop_item_title' );
		?>
		<h3><span><?php the_title(); ?></span></h3>
		<?php
		/**
		 * woocommerce_after_shop_loop_item_title hook.
		 *
		 * @hooked woocommerce_template_loop_rating - 5
		 * @hooked woocommerce_template_loop_price - 10
		 */
		do_action( 'woocommerce_after_shop_loop_item_title' );
		?>
	</a>

	<p class="prod-i-info">
		<?php
		$product_categories = get_the_terms( get_the_ID(), 'product_cat' );
		if (!empty($product_categories)) :
			?>
			<span class="prod-i-categ">
			<?php
			foreach ($product_categories as $key=>$product_category) :
				?>
				<a href="<?php echo get_term_link($product_category); ?>"><?php echo esc_attr($product_category->name); ?></a><?php break; ?><? if ($key+1 < count($product_categories)) { echo ', '; } ?>
			<?php endforeach; ?>
			</span>
		<?php endif; ?>
		
		<?php if ( $price_html = $product->get_price_html() ) : ?>
			<span class="prod-i-price"><?php echo $price_html; ?></span>
		<?php endif; ?>

		<?php if ($motor_options['catalog_request'] == 'yes') : ?>
			<a href="#" class="button request-form-btn"><?php esc_html_e('Request', 'motor'); ?></a>
		<?php else : ?>
			<?php woocommerce_template_loop_add_to_cart(array('button_text'=>esc_html__('+ Add to cart', 'motor'))); ?>
		<?php endif; ?>
	</p>


	<?php
	/**
	 * woocommerce_after_shop_loop_item hook.
	 *
	 * @hooked woocommerce_template_loop_product_link_close - 5
	 * @hooked woocommerce_template_loop_add_to_cart - 10
	 */
	do_action( 'woocommerce_after_shop_loop_item' );
	?>

	<?php motor_product_badge(get_the_ID(), 'prod-i-badge'); ?>

</article>
