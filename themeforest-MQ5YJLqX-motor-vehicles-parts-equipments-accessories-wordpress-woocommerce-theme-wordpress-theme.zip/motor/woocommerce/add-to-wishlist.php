<?php
/**
 * Add to wishlist template
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Wishlist
 * @version 3.0.0
 */

if ( ! defined( 'YITH_WCWL' ) ) {
	exit;
} // Exit if accessed directly

global $product;
?>

<div class="yith-wcwl-add-to-wishlist wishlist-fragment on-first-load add-to-wishlist-<?php echo esc_attr($product_id); ?> prod-li-favorites<?php echo ( $exists && ! $available_multi_wishlist ) ? ' wishlist-added' : '' ?>" data-fragment-ref="<?php echo $product_id ?>" data-fragment-options="<?php echo esc_attr( json_encode( $fragment_options ) )?>">
	<?php if( ! ( $disable_wishlist && ! is_user_logged_in() ) ): ?>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
        <?php yith_wcwl_get_template( 'add-to-wishlist-' . $template_part . '.php', $var ); ?>
        <?php
        if( $show_count ):
            echo yith_wcwl_get_count_text( $product_id );
        endif;
        ?>
	<?php else: ?>
		<a href="<?php echo esc_url( add_query_arg( array( 'wishlist_notice' => 'true', 'add_to_wishlist' => $product_id ), get_permalink( wc_get_page_id( 'myaccount' ) ) ) )?>" rel="nofollow" class="<?php echo str_replace( 'add_to_wishlist', '', $link_classes ) ?>" >
			<?php echo esc_attr($icon); ?>
			<?php echo esc_attr($label); ?>
		</a>
	<?php endif; ?>

</div>
