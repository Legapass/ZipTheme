<?php
/**
 * Product Loop Start
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/loop-start.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.0
 */

global $motor_options;

//remove_filter( 'woocommerce_product_loop_start', 'woocommerce_maybe_show_product_subcategories' );

$catalog_notroll = motor_option('catalog_notroll');
$view_mode = motor_option('catalog_viewmode', true);

if (!is_shop() && !is_product_taxonomy() && (!is_search() || empty($_GET['dgwt_wcas'])))
	$view_mode = 'gallery';

motor_content('shop_before_content');
?>
<?php if ($view_mode == 'gallery') : ?>
	<!-- Catalog Items (Gallery) - start -->
	<div class="prod-items section-gallery<?php if ($catalog_notroll == 'no') { echo ' prod-items-notroll'; } ?>">
<?php else: ?>
	<!-- Catalog Items (List) - start -->
	<div class="prod-litems section-list">
<?php endif; ?>