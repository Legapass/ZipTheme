<?php
/**
 * Add to wishlist button template - Browse list
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Wishlist
 * @version 3.0.0
 */

/**
 * Template variables:
 *
 * @var $wishlist_url string Url to wishlist page
 * @var $exists bool Whether current product is already in wishlist
 * @var $show_exists bool Whether to show already in wishlist link on multi wishlist
 * @var $product_id int Current product id
 * @var $product_type string Current product type
 * @var $label string Button label
 * @var $browse_wishlist_text string Browse wishlist text
 * @var $already_in_wishslist_text string Already in wishlist text
 * @var $product_added_text string Product added text
 * @var $icon string Icon for Add to Wishlist button
 * @var $link_classes string Classed for Add to Wishlist button
 * @var $available_multi_wishlist bool Whether add to wishlist is available or not
 * @var $disable_wishlist bool Whether wishlist is disabled or not
 * @var $template_part string Template part
 * @var $loop_position string Loop position
 */

if ( ! defined( 'YITH_WCWL' ) ) {
	exit;
} // Exit if accessed directly

global $product;
?>
<div class="yith-wcwl-wishlistexistsbrowse <?php echo ( $exists && ! $available_multi_wishlist ) ? 'show' : 'hide' ?>" style="display:<?php echo ( $exists && ! $available_multi_wishlist ) ? 'block' : 'none' ?>">
	<a class="active" href="<?php echo esc_url( $wishlist_url )?>" rel="nofollow"><svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.8123 2.0309L15.8185 2.03727L15.8248 2.04353C16.6108 2.8226 17 3.75901 17 4.91667C17 6.04054 16.615 6.96491 15.8248 7.74814L15.8211 7.75183L9 14.5846L2.17886 7.75183L2.17887 7.75182L2.17516 7.74814C1.38504 6.96491 1 6.04054 1 4.91667C1 3.75901 1.38924 2.8226 2.17516 2.04353L2.18147 2.03727L2.18767 2.0309C2.86484 1.33534 3.65933 1 4.62981 1C5.63619 1 6.44292 1.34034 7.11521 2.0309L7.11514 2.03097L7.12511 2.04093L8.29338 3.20759L8.98727 3.90053L9.69364 3.22032L10.9052 2.05365L10.9168 2.04246L10.9281 2.0309C11.6052 1.33534 12.3997 1 13.3702 1C14.3407 1 15.1352 1.33534 15.8123 2.0309Z" stroke="#858DAA" stroke-width="2"/></svg><span class="feedback"><span><?php esc_html_e('View Wishlist', 'motor'); ?></span></span></a>
</div>
