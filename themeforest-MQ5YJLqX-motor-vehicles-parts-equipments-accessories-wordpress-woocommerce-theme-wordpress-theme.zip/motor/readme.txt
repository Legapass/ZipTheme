﻿WordPress 4.0 Ready

WordPress 3+ Custom Menu Support

Responsive design

Blog post layout changing – for each page you can choose between:

    Right Sidebar

    Left Sidebar

    Fullwidth

Easy logo replacement

Sociable Icons section in footer and Social widget

SEO Ready

Contact form validator

Comments with reply functionality (multiple levels depth)

Works and looks similar in all major browsers: Internet Explorer, Firefox, Opera, Safari, Google Chrome

Documentation included
