<?php
global $motor_options;
?>

</div><?php /* #content */ ?>

<?php motor_footer(); ?>

<?php get_template_part('template-parts/modalform'); ?>

</div><?php /* #page */ ?>

<div class="main-searchform" id="main-searchform">
<div class="container">
	<form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
		<input type="text" value="<?php echo get_search_query(); ?>" name="s" placeholder="<?php esc_html_e('Search...', 'motor'); ?>">
		<input type="submit" value="<?php esc_html_e('search', 'motor'); ?>">
		<button class="main-searchform-close" id="main-searchform-close"><?php esc_html_e('close', 'motor'); ?><i class="ion-android-close"></i></button>
	</form>
</div>
</div>

<?php wp_footer(); ?>

</body>
</html>