<?php
// Get Options
if (!function_exists('motor_option')) {
	function motor_option($option, $allow_get = false) {
		global $motor_options;
		if (!empty($_GET[$option]) && $allow_get) {
			$value = $_GET[$option];
		} elseif (!empty($motor_options[$option])) {
			$value = $motor_options[$option];
		} elseif (empty($motor_options)) {
			include( trailingslashit( get_template_directory() ) . 'inc/get-options.php');
			$value = $motor_options[$option];
		} else {
			$value = get_theme_mod($option, '');
		}
		return $value;
	}
}


// Excerpt More from "[...]" to "..."
function motor_excerpt_more ($more) {
	return "...";
}
add_filter("excerpt_more", "motor_excerpt_more");


// New Excerpt Length
function motor_new_excerpt_length($length) {
	global $post;
	if ($post->post_type == 'post')
		return 20;
	elseif ($post->post_type == 'product')
		return 20;
	return 55;
}
add_filter('excerpt_length', 'motor_new_excerpt_length');


// Comment Template
function motor_comment($comment, $args, $depth){
	$GLOBALS['comment'] = $comment;
	$author  = get_comment_author( $comment );
	if (!empty($comment->user_id)) {
		$user_author_meta = get_user_meta($comment->user_id);
	}
	?>
<li <?php comment_class('post-comment'); ?> id="li-comment-<?php comment_ID() ?>">
	<div id="comment-<?php comment_ID(); ?>">
		<p class="post-comment-img">
			<?php if (function_exists('get_wp_user_avatar')) : ?>
				<?php echo get_wp_user_avatar($comment->comment_author_email); ?>
			<?php else: ?>
				<?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
			<?php endif; ?>
		</p>
		<h4 class="post-comment-ttl"><?php
			if (!empty($user_author_meta['first_name'][0]) || !empty($user_author_meta['last_name'][0])) {
				if (!empty($user_author_meta['first_name'][0])) {
					echo esc_attr($user_author_meta['first_name'][0]).' ';
				}
				if (!empty($user_author_meta['last_name'][0])) {
					echo esc_attr($user_author_meta['last_name'][0]);
				}
			} else {
				echo get_comment_author_link();
			}
			?> <?php edit_comment_link('(Edit)', '  ', '') ?></h4>
		<?php if ($comment->comment_approved == '0') : ?>
			<p><i><?php echo esc_html__( 'Your comment is awaiting moderation.', 'motor' ); ?></i></p>
		<?php endif; ?>
		<p class="comment-meta commentmetadata">
			<?php printf( '%1$s at %2$s', get_comment_date(),  get_comment_time()) ?>
			<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
		</p>
		<div class="post-comment-cont">
			<?php comment_text(); ?>
		</div>
	</div>
	<?php
}



// Get Attachment ID from src
function motor_get_attach_id_from_src($image_url) {
	global $wpdb, $table_prefix;

	$res = $wpdb->get_results('select post_id from ' . $table_prefix . 'postmeta where meta_value like "%' . basename($image_url). '%" and meta_key = "_wp_attached_file"');

	if(count($res) == 0)
	{
		$res = $wpdb->get_results('select ID as post_id from ' . $table_prefix . 'posts where guid="' . $image_url . '"');
	}

	return $res[0]->post_id;
}



// Include Header/Footer Custom Styles
/*if (!function_exists('motor_include_vc_custom_styles')) {
	function motor_include_vc_custom_styles($items) {
		if (!empty($items)) {
			$custom_vc_styles = '';
			foreach ($items as $item) {
				$item_meta = get_post_meta($item, '_wpb_shortcodes_custom_css', true);
				if (!empty($item_meta)) {
					$custom_vc_styles .= $item_meta;
				}
			}
			if (!empty($custom_vc_styles)) {
				$custom_vc_styles = preg_replace(
					*/
					//array('/:\s*/', '/\s*{\s*/', '/(;)*\s*}\s*/', '/\s+/'),
					/*
					array(':', '{', '}', ' '),
					$custom_vc_styles
				);
				wp_add_inline_style('dashicons', $custom_vc_styles);
				wp_enqueue_style('dashicons');
			}
		}
	}
}*/


// Get Custom Fonts
function motor_set_font_variables($args = array()) {

	if (empty($args['type'])) {
		return false;
	}

	$font = get_theme_mod($args['type'], array());

	// Font Family
	if (empty($font['font-family']) && !empty($args['font-family'])) {
		$font['font-family'] = $args['font-family'];
	}

	if (!empty($font['variant']) && in_array($font['variant'], array('italic', '100italic', '200italic', '300italic', '500italic', '600italic', '700italic', '800italic', '900italic'))) {
		$font['font-style'] = 'italic';
	} elseif (!empty($args['font-style'])) {
		$font['font-style'] = $args['font-style'];
	}

	// Font Weight
	$font['font-weight'] = '';
	if (!empty($font['variant'])) {
		$font['font-weight'] = $font['variant'];
	}
	if (empty($font['font-weight']) && !empty($args['font-weight'])) {
		$font['font-weight'] = $args['font-weight'];
	} elseif ($font['font-weight'] == 'regular') {
		$font['font-weight'] = '400';
	}  elseif ($font['font-weight'] == 'italic') {
		$font['font-weight'] = '400';
	} elseif ($font['font-weight'] == '100italic') {
		$font['font-weight'] = '100';
	} elseif ($font['font-weight'] == '200italic') {
		$font['font-weight'] = '200';
	} elseif ($font['font-weight'] == '300italic') {
		$font['font-weight'] = '300';
	} elseif ($font['font-weight'] == '500italic') {
		$font['font-weight'] = '500';
	} elseif ($font['font-weight'] == '600italic') {
		$font['font-weight'] = '600';
	} elseif ($font['font-weight'] == '700italic') {
		$font['font-weight'] = '700';
	} elseif ($font['font-weight'] == '800italic') {
		$font['font-weight'] = '800';
	} elseif ($font['font-weight'] == '900italic') {
		$font['font-weight'] = '900';
	}

	if (empty($font['font-size']) && !empty($args['font-size'])) {
		$font['font-size'] = $args['font-size'];
	}
	if (empty($font['line-height']) && !empty($args['line-height'])) {
		$font['line-height'] = $args['line-height'];
	}
	if (empty($font['letter-spacing']) && !empty($args['letter-spacing'])) {
		$font['letter-spacing'] = $args['letter-spacing'];
	}
	if (empty($font['text-align']) && !empty($args['text-align'])) {
		$font['text-align'] = $args['text-align'];
	}
	if (empty($font['color']) && !empty($args['color'])) {
		$font['color'] = $args['color'];
	}
	if (empty($font['text-transform']) && !empty($args['text-transform'])) {
		$font['text-transform'] = $args['text-transform'];
	}

	add_less_var( $args['type'], $font['font-family'] );
	add_less_var( $args['type'].'_fw', $font['font-weight'] );
	add_less_var( $args['type'].'_fs', $font['font-style'] );
	add_less_var( $args['type'].'_size', $font['font-size'] );
	add_less_var( $args['type'].'_lh', $font['line-height'] );
	add_less_var( $args['type'].'_ls', $font['letter-spacing'] );
	add_less_var( $args['type'].'_align', $font['text-align'] );
	add_less_var( $args['type'].'_color', $font['color'] );
	add_less_var( $args['type'].'_tt', $font['text-transform'] );

	return true;
}


function motor_projects_comments_default_off($data) {
    if ($data['post_type'] == 'motor_project' && $data['post_status'] == 'auto-draft') {
        $data['comment_status'] = 0;
    }

    return $data;
}
add_filter('wp_insert_post_data', 'motor_projects_comments_default_off');

// Load More Ajax
add_action('wp_ajax_nopriv_motor_load_more', 'motor_load_more');
add_action('wp_ajax_motor_load_more', 'motor_load_more');
function motor_load_more () {
	$nonce = $_POST['nonce'];
	if (!wp_verify_nonce($nonce, 'ajaxnonce')) {
		die ();
	}

    $file_type = htmlspecialchars($_POST['file_type']);

    if (!empty($file_type) && !empty(MOTOR_PLUGIN_DIR)) {
        switch ($file_type) {
            case 'products':
                include MOTOR_PLUGIN_DIR . 'inc/elementor/products-content.php';
                break;
            case 'posts':
                include MOTOR_PLUGIN_DIR . 'inc/elementor/posts-content.php';
                break;
            case 'projects':
                include MOTOR_PLUGIN_DIR . 'inc/elementor/projects-content.php';
                break;
        }
    }
    die();
}

// Quick View Ajax
add_action('wp_ajax_nopriv_motor_quick_view', 'motor_quick_view');
add_action('wp_ajax_motor_quick_view', 'motor_quick_view');
function motor_quick_view () {
	$nonce = $_POST['nonce'];
	if (!wp_verify_nonce($nonce, 'ajaxnonce')) {
		die ();
	}

	if ( ! isset( $_REQUEST['product_id'] ) ) {
		die();
	}

	$product_id = intval( $_REQUEST['product_id'] );

	wp( 'p=' . $product_id . '&post_type=product' );

    get_template_part('woocommerce/quickview-single-product');
	die();
}

add_action('wp_ajax_nopriv_motor_project_quick_view', 'motor_project_quick_view');
add_action('wp_ajax_motor_project_quick_view', 'motor_project_quick_view');
function motor_project_quick_view () {
	$nonce = $_POST['nonce'];
	if (!wp_verify_nonce($nonce, 'ajaxnonce')) {
		die ();
	}

    if (!isset($_REQUEST['project_id'])) {
        die();
    }

    $project_id = intval( $_REQUEST['project_id'] );

    wp( 'p=' . $project_id . '&post_type=motor_project' );

    get_template_part('template-parts/project-quickview');
    die();
}







class Motor_Mega_Menu_Walker extends Walker_Nav_Menu {
	public $elementor_items = array();
	public $elementor_items_menu = array();

	/**
	 * Starts the element output.
	 *
	 * @since 3.0.0
	 * @since 4.4.0 The {@see 'nav_menu_item_args'} filter was added.
	 *
	 * @see Walker::start_el()
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 * @param int      $id     Current item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		global $motor_options;

		if (empty($this->elementor_items)) {
			if (!empty($motor_options['menu_items'])) {
				$this->elementor_items = $motor_options['menu_items'];
			} else {
				$this->elementor_items = motor_get_posts( array( 'posts_per_page' => -1, 'post_type' => 'motor_mega_menu', 'post_status'=>'any', 'meta_key' => 'motor_mega_menu_item_id' ));
			}
			foreach ($this->elementor_items as $id=>$title) {
				$menu_item = get_post_meta($id, 'motor_mega_menu_item_id', true);
				if (!empty($menu_item)) {
					$this->elementor_items_menu[$menu_item] = $id;
				}
			}
		}

		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$t = '';
			$n = '';
		} else {
			$t = "\t";
			$n = "\n";
		}
		$indent = ( $depth ) ? str_repeat( $t, $depth ) : '';

		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'menu-item-' . $item->ID;

		if (!empty($this->elementor_items) && array_key_exists($item->ID, $this->elementor_items_menu)) {
			$classes[] = 'motor-menu-depth-' . $depth;
			$classes[] = 'motor-mega-menu-item';


		foreach ($this->elementor_items_menu as $menu_item_id => $menu_post_id) {
			if ($menu_item_id === $item->ID) {
				$menu_width = get_post_meta($menu_post_id, 'motor_mega_menu_width', true);
				$menu_width_custom = get_post_meta($menu_post_id, 'motor_mega_menu_width_custom', true);
				$menu_width_custom_offset = get_post_meta($menu_post_id, 'motor_mega_menu_width_custom_offset', true);
				$classes[] = 'mega-menu-width-'.$menu_width;
			}
		}


		}

		/**
		 * Filters the arguments for a single nav menu item.
		 *
		 * @since 4.4.0
		 *
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param WP_Post  $item  Menu item data object.
		 * @param int      $depth Depth of menu item. Used for padding.
		 */
		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		/**
		 * Filters the CSS class(es) applied to a menu item's list item element.
		 *
		 * @since 3.0.0
		 * @since 4.1.0 The `$depth` parameter was added.
		 *
		 * @param array    $classes The CSS classes that are applied to the menu item's `<li>` element.
		 * @param WP_Post  $item    The current menu item.
		 * @param stdClass $args    An object of wp_nav_menu() arguments.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 */
		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		/**
		 * Filters the ID applied to a menu item's list item element.
		 *
		 * @since 3.0.1
		 * @since 4.1.0 The `$depth` parameter was added.
		 *
		 * @param string   $menu_id The ID that is applied to the menu item's `<li>` element.
		 * @param WP_Post  $item    The current menu item.
		 * @param stdClass $args    An object of wp_nav_menu() arguments.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 */
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args, $depth );
		$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $class_names .'>';

		$atts = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target )     ? $item->target     : '';
		$atts['rel']    = ! empty( $item->xfn )        ? $item->xfn        : '';
		$atts['href']   = ! empty( $item->url )        ? $item->url        : '';

		/**
		 * Filters the HTML attributes applied to a menu item's anchor element.
		 *
		 * @since 3.6.0
		 * @since 4.1.0 The `$depth` parameter was added.
		 *
		 * @param array $atts {
		 *     The HTML attributes applied to the menu item's `<a>` element, empty strings are ignored.
		 *
		 *     @type string $title  Title attribute.
		 *     @type string $target Target attribute.
		 *     @type string $rel    The rel attribute.
		 *     @type string $href   The href attribute.
		 * }
		 * @param WP_Post  $item  The current menu item.
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param int      $depth Depth of menu item. Used for padding.
		 */
		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				$value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		/** This filter is documented in wp-includes/post-template.php */
		$title = apply_filters( 'the_title', $item->title, $item->ID );

		/**
		 * Filters a menu item's title.
		 *
		 * @since 4.4.0
		 *
		 * @param string   $title The menu item's title.
		 * @param WP_Post  $item  The current menu item.
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param int      $depth Depth of menu item. Used for padding.
		 */
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		$item_output = $args->before;
		$item_output .= '<a'. $attributes .'>';
		$item_output .= $args->link_before . $title . $args->link_after;
		$item_output .= '</a>';
		$item_output .= $args->after;

		if (!empty($this->elementor_items) && array_key_exists($item->ID, $this->elementor_items_menu)) {
			$item_output .= \Elementor\Plugin::$instance->frontend->get_builder_content( intval($this->elementor_items_menu[$item->ID]) );
		}

		/**
		 * Filters a menu item's starting output.
		 *
		 * The menu item's starting output only includes `$args->before`, the opening `<a>`,
		 * the menu item's title, the closing `</a>`, and `$args->after`. Currently, there is
		 * no filter for modifying the opening and closing `<li>` for a menu item.
		 *
		 * @since 3.0.0
		 *
		 * @param string   $item_output The menu item's starting HTML output.
		 * @param WP_Post  $item        Menu item data object.
		 * @param int      $depth       Depth of menu item. Used for padding.
		 * @param stdClass $args        An object of wp_nav_menu() arguments.
		 */
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
}



function motor_menu_styles() {
    $custom_css = '';
    $mega_menu = motor_get_posts( array( 'posts_per_page' => -1, 'post_type' => 'motor_mega_menu', 'post_status'=>'any', 'meta_key' => 'motor_mega_menu_item_id' ));
    foreach ($mega_menu as $id=>$title) {
        $menu_item = get_post_meta($id, 'motor_mega_menu_item_id', true);
        $menu_width = get_post_meta($id, 'motor_mega_menu_width', true);
        if (!empty($menu_item) && !empty($menu_width) && $menu_width == 'custom') {
            $menu_width_custom = get_post_meta($id, 'motor_mega_menu_width_custom', true);
            $menu_width_custom_offset = get_post_meta($id, 'motor_mega_menu_width_custom_offset', true);
            if (!empty($menu_width_custom)) {
                $custom_css .= ".el-menu > ul li.motor-mega-menu-item.mega-menu-width-custom.menu-item-{$menu_item}:hover .elementor { width: {$menu_width_custom}px; }";
            }
            if (!empty($menu_width_custom_offset)) {
                $custom_css .= ".el-menu > ul li.motor-mega-menu-item.mega-menu-width-custom.menu-item-{$menu_item}:hover .elementor { margin-left: {$menu_width_custom_offset}px; }";
            }
        }
    }

    echo "<style>".$custom_css."</style>";
}
add_action('wp_head', 'motor_menu_styles', 100);



function motor_add_file_types_to_uploads($file_types)
{
    $new_filetypes = array();
    $new_filetypes['svg'] = 'image/svg+xml';
    $new_filetypes['svgz'] = 'image/svg+xml';
    $file_types = array_merge($file_types, $new_filetypes);

    return $file_types;
}

add_action('upload_mimes', 'motor_add_file_types_to_uploads');



function motor_metro_column($index, $layout) {
    $columns = array();
    $columns_height = array();
    foreach ($layout as $row) {
        if (is_object($row)) {
            $row = (array)$row;
        }

        if (!empty($row['template'])) {
            $row_columns = explode('+', $row['template']);
            $columns = array_merge($columns, $row_columns);
            foreach ($row_columns as $item) {
                $columns_height[] = $row['height'];
            }
        }
    }

    if (empty($columns)) {
        return '';
    }

    if ($index < count($columns)) {
        $column = $columns[$index];
        $height = $columns_height[$index];
    } else {
        $index = $index % count($columns);
        $column = $columns[$index];
        $height = $columns_height[$index];
    }

    return array('height' => $height, 'column' => $column);
}

function motor_packery_column($index, $layout, $default) {
    $width = '';
    switch ($default) {
        case 1: $width = 12; break;
        case 2: $width = 6; break;
        case 3: $width = 4; break;
        case 4: $width = 3; break;
        case 6: $width = 2; break;
    }
    $height = 1;

    foreach ($layout as $item) {
        if (is_object($item)) {
            $item = (array)$item;
        }

        if (!empty($item['loop'])) {
            if ($index % $item['loop'] == $item['index'] || ($index % $item['loop'] === 0 && $item['loop'] == $item['index'])) {
                $width = (int)$item['width'];
                if (!empty($item['height'])) {
                    $height = (float)$item['height'];
                }
            }
        } elseif (intval($item['index']) === $index) {
            $width = (int)$item['width'];
            if (!empty($item['height'])) {
                $height = (float)$item['height'];
            }
        }
    }

    return array('width' => $width, 'height' => $height);
}


function motor_jpeg_quality($arg) {
    return 100;
}
add_filter('jpeg_quality', 'motor_jpeg_quality');




function motor_get_posts($args) {
    if ( is_string( $args ) ) {
        $args = add_query_arg(
            array(
                'suppress_filters' => false,
            )
        );
    } elseif ( is_array( $args ) && ! isset( $args['suppress_filters'] ) ) {
        $args['suppress_filters'] = false;
    }

    // Get the posts.
    $posts = get_posts( $args );

    // Properly format the array.
    $items = array();
    foreach ( $posts as $post ) {
        $items[ $post->ID ] = $post->post_title;
    }
    wp_reset_postdata();

    return $items;
}



function motor_footer_get_id() {
    global $motor_options;

    $footer_template = $motor_options['footer_template'];
    if (is_page()) {
        $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model(get_the_ID());
        $page_footer = $page_settings->get_settings('page_footer');
        if (!empty($page_footer)) {
            $footer_template = $page_footer;
        }
    } elseif (function_exists('is_shop') && is_shop() && !empty($motor_options['footer_template_shop_root'])) {
        $footer_template = $motor_options['footer_template_shop_root'];
    } elseif (function_exists('is_product_category') && is_product_category()) {
        $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
        $motor_product_cat = get_option('motor_product_cat_'.$term_id);
        if (!empty($motor_product_cat['footer'])) {
            $footer_template = $motor_product_cat['footer'];
        } elseif (!empty($motor_options['footer_template_shop_category'])) {
            $footer_template = $motor_options['footer_template_shop_category'];
        }
    } elseif (function_exists('is_product') && is_product()) {
        $motor_post_footer = get_post_meta(get_the_ID(), 'motor_product_footer', true);
        if (!empty($motor_post_footer)) {
            $footer_template = $motor_post_footer;
        } elseif (!empty($motor_options['footer_template_shop_single'])) {
            $footer_template = $motor_options['footer_template_shop_single'];
        }
    } elseif (is_tax('motor_project_category')) {
        if (!empty($motor_options['footer_template_projects_category'])) {
            $footer_template = $motor_options['footer_template_projects_category'];
        }
    } elseif (is_singular('motor_project')) {
        $motor_project_footer = get_post_meta(get_the_ID(), 'motor_project_footer', true);
        if (!empty($motor_project_footer)) {
            $footer_template = $motor_project_footer;
        } elseif (!empty($motor_options['footer_template_projects_single'])) {
            $footer_template = $motor_options['footer_template_projects_single'];
        }
    } elseif (is_home() && !empty($motor_options['footer_template_blog_root'])) {
        $footer_template = $motor_options['footer_template_blog_root'];
    } elseif (is_category()) {
        $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
        $motor_category = get_option('motor_category_'.$term_id);
        if (!empty($motor_category['footer'])) {
            $footer_template = $motor_category['footer'];
        } elseif (!empty($motor_options['footer_template_blog_category'])) {
            $footer_template = $motor_options['footer_template_blog_category'];
        }
    } elseif (is_single()) {
        $motor_post_footer = get_post_meta(get_the_ID(), 'motor_post_footer', true);
        if (!empty($motor_post_footer)) {
            $footer_template = $motor_post_footer;
        } elseif (!empty($motor_options['footer_template_blog_single'])) {
            $footer_template = $motor_options['footer_template_blog_single'];
        }
    } elseif (is_404() && !empty($motor_options['other_err404'])) {
        $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model($motor_options['other_err404']);
        $page_footer = $page_settings->get_settings('page_footer');
        if (!empty($page_footer)) {
            $footer_template = $page_footer;
        }
    }

	if (function_exists('icl_object_id')) {
		$footer_template = icl_object_id($footer_template, 'page', false, ICL_LANGUAGE_CODE);
	}

	$motor_options['footer_id'] = intval($footer_template);

	return intval($footer_template);
}



function motor_footer() {
	global $motor_options;

	if (!defined('ELEMENTOR_VERSION')) {
        return false;
    }

	if (!empty($motor_options['footer_id'])) {
		$footer_id = $motor_options['footer_id'];
	} else {
		$footer_id = motor_footer_get_id();
	}

    if (!empty($footer_id)) {
        echo '<footer class="site-footer">'.\Elementor\Plugin::$instance->frontend->get_builder_content( intval($footer_id) ).'</footer>';
    }
}




function motor_title_block_get_id() {
    global $motor_options;

    if (is_page()) {
        $title_block = '';
        if (defined('ELEMENTOR_VERSION')) {
            $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model(get_the_ID());
            $page_title_block = $page_settings->get_settings('page_title_block');
        }

        if (empty($page_title_block) || $page_title_block == 'default') {
            $title_block = $motor_options['title_template'];

            if ($title_block == 'normal') {
                $title_block = 'only-breadcrumbs';
            }
        } else {
            $title_block = $page_title_block;
        }
    } elseif (function_exists('is_shop') && is_shop() && !empty($motor_options['title_template_shop_root'])) {
        $title_block = $motor_options['title_template_shop_root'];
    } elseif (function_exists('is_product_category') && is_product_category()) {
        $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
        $motor_product_cat = get_option('motor_product_cat_'.$term_id);
        if (!empty($motor_product_cat['title'])) {
            $title_block = $motor_product_cat['title'];
        } elseif (!empty($motor_options['title_template_shop_category'])) {
            $title_block = $motor_options['title_template_shop_category'];
        }
    } elseif (function_exists('is_product') && is_product()) {
        $motor_post_title = get_post_meta(get_the_ID(), 'motor_product_title', true);
        if (!empty($motor_post_title)) {
            $title_block = $motor_post_title;
        } elseif (!empty($motor_options['title_template_shop_single'])) {
            $title_block = $motor_options['title_template_shop_single'];
        }
    } elseif (is_tax('motor_project_category')) {
        $title = single_term_title('', false);
        if (!empty($motor_options['title_template_projects_category'])) {
            $title_block = $motor_options['title_template_projects_category'];
        }
    } elseif (is_singular('motor_project')) {
        $motor_project_title = get_post_meta(get_the_ID(), 'motor_project_title', true);
        if (!empty($motor_project_title)) {
            $title_block = $motor_project_title;
        } elseif (!empty($motor_options['title_template_projects_single'])) {
            $title_block = $motor_options['title_template_projects_single'];
        }
    } elseif (is_home() && !empty($motor_options['title_template_blog_root'])) {
        $title_block = $motor_options['title_template_blog_root'];
    } elseif (is_category()) {
        $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
        $motor_category = get_option('motor_category_'.$term_id);
        if (!empty($motor_category['title'])) {
            $title_block = $motor_category['title'];
        } elseif (!empty($motor_options['title_template_blog_category'])) {
            $title_block = $motor_options['title_template_blog_category'];
        }
    } elseif (is_single()) {
        $motor_post_title = get_post_meta(get_the_ID(), 'motor_post_title', true);
        if (!empty($motor_post_title)) {
            $title_block = $motor_post_title;
        } elseif (!empty($motor_options['title_template_blog_single'])) {
            $title_block = $motor_options['title_template_blog_single'];
        }
    }

    if (empty($title_block)) {
        return;
    }

	if (function_exists('icl_object_id')) {
		$title_block = icl_object_id($title_block, 'page', false, ICL_LANGUAGE_CODE);
	}

	$motor_options['title_id'] = $title_block;

	return $title_block;
}


function motor_title_block_render($title_block = 'normal', $title = '') {
	global $motor_options;

	if (!empty($motor_options['title_id'])) {
		$title_block = $motor_options['title_id'];
	} else {
		$title_block_id = motor_title_block_get_id();
		if (!empty($title_block_id)) {
			$title_block = $title_block_id;
		}
	}

    if (empty($title_block)) {
        return;
    }

    switch ($title_block) {
        case 'only-breadcrumbs':
            ?>
            <div class="b-crumbs-wrap">
                <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                    <div class="cont b-crumbs">
                        <?php woocommerce_breadcrumb(array('wrap_before'=>'<ul>', 'wrap_after'=>'</ul>', 'before'=>'<li>', 'after'=>'</li>', 'delimiter'=>'')); ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php
            break;
        case 'normal':
            ?>
            <div class="b-crumbs-wrap">
                <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                    <div class="cont b-crumbs">
                        <?php woocommerce_breadcrumb(array('wrap_before'=>'<ul>', 'wrap_after'=>'</ul>', 'before'=>'<li>', 'after'=>'</li>', 'delimiter'=>'')); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="container title-block">
                <h1><span><?php the_title(); ?></span></h1>
                <span class="maincont-line1"></span>
                <span class="maincont-line2"></span>
            </div>
            <?php
            break;
        case 'normal-project':
            echo '<div class="container project-item-title">';
            $category = get_the_terms(get_the_ID(), 'motor_project_category');
            if (!empty($category)) :
                ?>
                <p>
                    <?php foreach ($category as $key=>$cat) : ?><a href="<?php echo esc_attr(get_category_link($cat->term_id)); ?>"><?php echo esc_attr($cat->name); ?></a><?php echo ($key+1<count($category)) ? ', ' : ''; endforeach; ?>
                </p>
            <?php endif;
            ?>
            <h1><?php the_title(); ?></h1>
            <?php
            echo '</div>';
            break;
        case 'hide':
            return;
            break;
        default:
            $title_block = intval($title_block);
            echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($title_block) );
            break;
    }
}




function motor_header_get_id() {
    global $motor_options;

    $header_template = $motor_options['header_template'];
    if (is_page()) {
        $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model(get_the_ID());
        $header_custom = $page_settings->get_settings('page_header');
    } elseif (function_exists('is_shop') && is_shop() && !empty($motor_options['header_template_shop_root'])) {
        $header_custom = $motor_options['header_template_shop_root'];
    } elseif (function_exists('is_product_category') && is_product_category()) {
        $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
        $motor_product_cat = get_option('motor_product_cat_'.$term_id);
        if (!empty($motor_product_cat['header'])) {
            $header_custom = $motor_product_cat['header'];
        } elseif (!empty($motor_options['header_template_shop_category'])) {
            $header_custom = $motor_options['header_template_shop_category'];
        }
    } elseif (function_exists('is_product') && is_product()) {
        $motor_post_header = get_post_meta(get_the_ID(), 'motor_product_header', true);
        if (!empty($motor_post_header)) {
            $header_custom = $motor_post_header;
        } elseif (!empty($motor_options['header_template_shop_single'])) {
            $header_custom = $motor_options['header_template_shop_single'];
        }
    } elseif (is_tax('motor_project_category')) {
        if (!empty($motor_options['header_template_projects_category'])) {
            $header_custom = $motor_options['header_template_projects_category'];
        }
    } elseif (is_singular('motor_project')) {
        $motor_project_header = get_post_meta(get_the_ID(), 'motor_project_header', true);
        if (!empty($motor_project_header)) {
            $header_custom = $motor_project_header;
        } elseif (!empty($motor_options['header_template_projects_single'])) {
            $header_custom = $motor_options['header_template_projects_single'];
        }
    } elseif (is_home() && !empty($motor_options['header_template_blog_root'])) {
        $header_custom = $motor_options['header_template_blog_root'];
    } elseif (is_category()) {
        $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
        $motor_category = get_option('motor_category_'.$term_id);
        if (!empty($motor_category['header'])) {
            $header_custom = $motor_category['header'];
        } elseif (!empty($motor_options['header_template_blog_category'])) {
            $header_custom = $motor_options['header_template_blog_category'];
        }
    } elseif (is_single()) {
        $motor_post_header = get_post_meta(get_the_ID(), 'motor_post_header', true);
        if (!empty($motor_post_header)) {
            $header_custom = $motor_post_header;
        } elseif (!empty($motor_options['header_template_blog_single'])) {
            $header_custom = $motor_options['header_template_blog_single'];
        }
    } elseif (is_404() && !empty($motor_options['other_err404'])) {
        $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model($motor_options['other_err404']);
        $header_custom = $page_settings->get_settings('page_header');
    }
    if (!empty($header_custom)) {
        $header_template = intval($header_custom);
    }

	if (function_exists('icl_object_id')) {
		$header_template = icl_object_id($header_template, 'page', false, ICL_LANGUAGE_CODE);
	}

	$motor_options['header_id'] = intval($header_template);
	
	return $header_template;
}


function motor_header() {
	global $motor_options;

    if (!defined('ELEMENTOR_VERSION')) {
        get_template_part('template-parts/header-default');
        return;
    }

	if (!empty($motor_options['header_id'])) {
		$header_id = $motor_options['header_id'];
	} else {
		$header_id = motor_header_get_id();
	}

    if (!empty($header_id)) {
        $header_overlay = get_post_meta(intval($header_id), 'motor_header_overlay', true);
        $header_sticky = get_post_meta(intval($header_id), 'motor_header_sticky', true);
        $overlay = '';
        if (!empty($header_overlay) && $header_overlay == 'yes') {
            $overlay = ' site-header-overlay';
        }
        $sticky = '';
        if (!empty($header_sticky) && $header_sticky == 'yes') {
            $sticky = ' site-header-sticky';
        }
        echo '<header id="site-header" class="site-header'.esc_attr($overlay).esc_attr($sticky).'">'.\Elementor\Plugin::$instance->frontend->get_builder_content( intval($header_id) ).'</header>';
    } else {
        get_template_part('template-parts/header-default');
    }
}




function motor_content($area) {
    if (!defined('ELEMENTOR_VERSION')) {
        return false;
    }

    if (in_array($area, array('shop_before_content', 'shop_after_content', 'shop_sidebar')) && !class_exists('WooCommerce')) {
        return false;
    }

    global $motor_options;

    switch ($area) {
        case 'shop_after_title':
            if (is_shop()) {
                if (!empty($motor_options['areas_shop_root_after_title'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_root_after_title']), true );
                }
            } elseif (is_product_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_product_cat = get_option('motor_product_cat_'.$term_id);
                if (!empty($motor_product_cat['after_title'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_cat['after_title']) );
                } elseif (!empty($motor_options['areas_shop_category_after_title'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_category_after_title']), true );
                }
            }
            break;
        case 'shop_before_content':
            if (is_shop()) {
                if (!empty($motor_options['areas_shop_root_before_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_root_before_content']), true );
                }
            } elseif (is_product_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_product_cat = get_option('motor_product_cat_'.$term_id);
                if (!empty($motor_product_cat['before_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_cat['before_content']), true );
                } elseif (!empty($motor_options['areas_shop_category_before_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_category_before_content']), true );
                }
            }
            break;
        case 'shop_after_content':
            if (is_shop()) {
                if (!empty($motor_options['areas_shop_root_after_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_root_after_content']), true );
                }
            } elseif (is_product_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_product_cat = get_option('motor_product_cat_'.$term_id);
                if (!empty($motor_product_cat['after_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_cat['after_content']), true );
                } elseif (!empty($motor_options['areas_shop_category_after_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_category_after_content']), true );
                }
            }
            break;
        case 'shop_sidebar':
            if (is_shop()) {
                if (!empty($motor_options['areas_shop_root_sidebar'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_root_sidebar']), true );
                }
            } elseif (is_product_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_product_cat = get_option('motor_product_cat_'.$term_id);
                if (!empty($motor_product_cat['sidebar'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_cat['sidebar']), true );
                } elseif (!empty($motor_options['areas_shop_category_sidebar'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_category_sidebar']), true );
                }
            }
            break;
        case 'shop_before_footer':
            if (is_shop()) {
                if (!empty($motor_options['areas_shop_root_before_footer'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_root_before_footer']), true );
                }
            } elseif (is_product_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_product_cat = get_option('motor_product_cat_'.$term_id);
                if (!empty($motor_product_cat['before_footer'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_cat['before_footer']), true );
                } elseif (!empty($motor_options['areas_shop_category_before_footer'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_category_before_footer']), true );
                }
            }
            break;
        case 'shop_single_before_content':
            $motor_product_before_content = get_post_meta(get_the_ID(), 'motor_product_before_content', true);
            if (!empty($motor_product_before_content)) {
                echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_before_content), true );
            } elseif (!empty($motor_options['areas_shop_single_before_content'])) {
                echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_single_before_content']), true );
            }
            break;
        case 'shop_single_after_content':
            $motor_product_after_content = get_post_meta(get_the_ID(), 'motor_product_after_content', true);
            if (!empty($motor_product_after_content)) {
                echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_product_after_content), true );
            } elseif (!empty($motor_options['areas_shop_single_after_content'])) {
                echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_shop_single_after_content']), true );
            }
            break;
        case 'blog_before_content':
            if (is_home()) {
                if (!empty($motor_options['areas_blog_root_before_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_root_before_content']), true );
                }
            } elseif (is_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_category = get_option('motor_category_'.$term_id);
                if (!empty($motor_category['before_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_category['before_content']), true );
                } elseif (!empty($motor_options['areas_blog_category_before_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_category_before_content']), true );
                }
            }
            break;
        case 'blog_after_content':
            if (is_home()) {
                if (!empty($motor_options['areas_blog_root_after_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_root_after_content']), true );
                }
            } elseif (is_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_category = get_option('motor_category_'.$term_id);
                if (!empty($motor_category['after_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_category['after_content']), true );
                } elseif (!empty($motor_options['areas_blog_category_after_content'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_category_after_content']), true );
                }
            }
            break;
        case 'blog_sidebar':
            if (is_home()) {
                if (!empty($motor_options['areas_blog_root_sidebar'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_root_sidebar']), true );
                }
            } elseif (is_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_category = get_option('motor_category_'.$term_id);
                if (!empty($motor_category['sidebar'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_category['sidebar']), true );
                } elseif (!empty($motor_options['areas_blog_category_sidebar'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_category_sidebar']), true );
                }
            }
            break;
        case 'blog_after_title':
            if (is_home()) {
                if (!empty($motor_options['areas_blog_root_after_title'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_root_after_title']), true );
                }
            } elseif (is_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_category = get_option('motor_category_'.$term_id);
                if (!empty($motor_category['after_title'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_category['after_title']), true );
                } elseif (!empty($motor_options['areas_blog_category_after_title'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_category_after_title']), true );
                }
            }
            break;
        case 'blog_before_footer':
            if (is_home()) {
                if (!empty($motor_options['areas_blog_root_before_footer'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_root_before_footer']), true );
                }
            } elseif (is_category()) {
                $term_id = (isset(get_queried_object()->term_id)) ? get_queried_object()->term_id : '';
                $motor_category = get_option('motor_category_'.$term_id);
                if (!empty($motor_category['before_footer'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_category['before_footer']), true );
                } elseif (!empty($motor_options['areas_blog_category_before_footer'])) {
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content( intval($motor_options['areas_blog_category_before_footer']), true );
                }
            }
            break;
    }
}




function motor_get_contents($file) {
    global $wp_filesystem;
    if (empty($wp_filesystem)) {
        require_once (ABSPATH . '/wp-admin/includes/file.php');
        WP_Filesystem();
    }
    return $wp_filesystem->get_contents($file);
}




if ( ! function_exists( 'motor_elementor_page_settings' ) ) {
    function motor_elementor_page_settings($document, $control_id = 'template')
	{

        $document->start_injection( [
            'of' => 'post_status',
        ] );

        $header_footer = array();
        if (current_user_can( 'manage_options' )) {
            $header_footer = motor_get_posts( array( 'posts_per_page' => -1, 'post_type' => 'motor_header', 'post_status'=>'any' ));
            $header_footer[0] = __('- Default', 'motor');
        }

        $document->add_control(
            'page_header_precreated',
            [
                'label' => __('Precreated Header', 'motor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => array(
					'default' => esc_html__('Default', 'motor'),
					'hide' => esc_html__('Hide', 'motor'),
					'header-1' => esc_html__('Precreated Header', 'motor'),
                ),
            ]
        );

        $document->add_control(
            'page_header',
            [
                'label' => __('Header', 'motor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => $header_footer,
            ]
        );

        $document->add_control(
            'page_footer',
            [
                'label' => __('Footer', 'motor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => $header_footer,
            ]
        );

        $page_title_options = array(/*'default' => esc_html__('Default', 'motor'), */'hide' => esc_html__('- Hide', 'motor'), 'only-breadcrumbs' => esc_html__('- Only Breadcrumbs', 'motor'));
        if (!empty($header_footer)) {
            foreach ($header_footer as $key=>$item) {
                if (!empty($item)) {
                    $page_title_options[$key] = $item;
                }
            }
        }

        $document->add_control(
            'page_title_block',
            [
                'label' => __('Title Block', 'motor'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 0,
                'options' => $page_title_options,
            ]
        );

        $document->add_control(
            'page_reload_info',
            [
                'raw' => __( 'To apply changes please SAVE and RELOAD page', 'motor' ),
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'content_classes' => 'elementor-descriptor',
            ]
        );

        $document->end_injection();
	}
}
add_action('elementor/documents/register_controls', 'motor_elementor_page_settings');



/**
 * Load Elementor styles on all pages in the head to avoid CSS files being loaded in the footer
 */
function motor_elementor_css_in_head() {
	if (class_exists('\Elementor\Plugin')) {
		$elementor = \Elementor\Plugin::instance();
		$elementor->frontend->enqueue_styles();
	}
	if (class_exists('\ElementorPro\Plugin')) {
		$elementor = \ElementorPro\Plugin::instance();
		$elementor->enqueue_styles();
	}
	if (class_exists('Elementor\Core\Files\CSS\Post')) {
		$header_id = motor_header_get_id();
		$header_css_file = new Elementor\Core\Files\CSS\Post($header_id);
		$header_css_file->enqueue();

		$footer_id = motor_footer_get_id();
		$footer_css_file = new Elementor\Core\Files\CSS\Post($footer_id);
		$footer_css_file->enqueue();

		$title_id = motor_title_block_get_id();
		$title_css_file = new Elementor\Core\Files\CSS\Post($title_id);
		$title_css_file->enqueue();

		$menu_items = motor_get_posts( array( 'posts_per_page' => -1, 'post_type' => 'motor_mega_menu', 'post_status'=>'any', 'meta_key' => 'motor_mega_menu_item_id' ));
		if (!empty($menu_items)) {
			global $motor_options;
			$motor_options['menu_items'] = $menu_items;
			foreach ($menu_items as $menu_id=>$title) {
				$menu_css_file = new Elementor\Core\Files\CSS\Post($menu_id);
				$menu_css_file->enqueue();
			}
		}
	}
}
add_action('wp_enqueue_scripts', 'motor_elementor_css_in_head');
