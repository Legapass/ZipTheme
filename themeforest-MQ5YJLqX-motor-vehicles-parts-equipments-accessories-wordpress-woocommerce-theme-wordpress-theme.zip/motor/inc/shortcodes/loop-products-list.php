<?php
// Extra post classes
$classes = array();
$classes[] = 'prod-li sectls';

global $product, $motor_options;

$sku = $product->get_sku();
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>

	<div class="prod-li-inner">
		
	<a href="<?php the_permalink(); ?>" class="prod-li-img">
		<?php echo woocommerce_get_product_thumbnail(); ?>
	</a>
	<div class="prod-li-cont">
		<?php
		/**
		 * woocommerce_before_shop_loop_item hook.
		 *
		 * @hooked woocommerce_template_loop_product_link_open - 10
		 */
		do_action( 'woocommerce_before_shop_loop_item' );
		?>
		<div class="prod-li-ttl-wrap">
			<p>
				<?php
				$product_categories = get_the_terms( get_the_ID(), 'product_cat' );
				if (!empty($product_categories)) :
					foreach ($product_categories as $key=>$product_category) :
						?>
					<a href="<?php echo get_term_link($product_category); ?>">
						<?php echo esc_attr($product_category->name); ?>
						</a><?php if ($key+1 < count($product_categories)) echo ',&nbsp;'; ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</p>
			<?php
			/**
			 * woocommerce_before_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_show_product_loop_sale_flash - 10
			 * @hooked woocommerce_template_loop_product_thumbnail - 10
			 */
			do_action( 'woocommerce_before_shop_loop_item_title' );
			?>
			<?php
			/**
			 * woocommerce_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_template_loop_product_title - 10
			 */
			do_action( 'woocommerce_shop_loop_item_title' );
			?>
			<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
			<?php
			/**
			 * woocommerce_after_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_template_loop_rating - 5
			 * @hooked woocommerce_template_loop_price - 10
			 */
			do_action( 'woocommerce_after_shop_loop_item_title' );
			?>
		</div>
		<div class="prod-li-price-wrap">
			<p><?php echo esc_html__('Price', 'motor'); ?></p>
			<?php if ( $price_html = $product->get_price_html() ) : ?><p class="prod-li-price"><?php echo $price_html; ?></p><?php endif; ?>
		</div>
		<div class="prod-li-qnt-wrap">
			<p><?php echo esc_html__('Quantity', 'motor'); ?></p>
			<?php
			woocommerce_quantity_input( array(
				'max_value'     => $product->get_max_purchase_quantity(),
				'min_value'     => '0',
				'product_name'  => $product->get_name(),
				'price' => wc_get_price_to_display($product),
			), $product );
			?>
		</div>
		<div class="prod-li-total-wrap">
			<p><?php echo esc_html__('Total', 'motor'); ?></p>
			<?php if ( $price_html = $product->get_price_html() ) : ?><p class="prod-li-total"><?php echo $price_html; ?></p><?php endif; ?>
		</div>
		<?php
		/**
		 * woocommerce_after_shop_loop_item hook.
		 *
		 * @hooked woocommerce_template_loop_product_link_close - 5
		 * @hooked woocommerce_template_loop_add_to_cart - 10
		 */
		do_action( 'woocommerce_after_shop_loop_item' );
		?>
	</div>
	<div class="prod-li-info<?php if (empty($sku)) echo ' no-sku'; ?><?php if (!comments_open()) echo ' no-rating'; ?>">
		<?php if ( comments_open() ) { ?>
		<div class="prod-li-rating-wrap">
			<p data-rating="<?php echo round($product->get_average_rating()); ?>" class="prod-li-rating">
				<i class="fa fa-star-o" title="5"></i><i class="fa fa-star-o" title="4"></i><i class="fa fa-star-o" title="3"></i><i class="fa fa-star-o" title="2"></i><i class="fa fa-star-o" title="1"></i>
			</p>
			<p><span class="prod-li-rating-count"><?php echo intval($product->get_review_count()); ?></span> <?php echo _n( 'review', 'reviews', $product->get_review_count(), 'motor' ); ?></p>
		</div>
		<?php } ?>

		<?php motor_list_info_button(); ?>

		<p class="prod-li-add">
			<?php if ($motor_options['catalog_request'] == 'yes') : ?>
				<a href="#" class="button request-form-btn"><?php esc_html_e('Request', 'motor'); ?></a>
			<?php else : ?>
				<?php woocommerce_template_loop_add_to_cart(); ?>
			<?php endif; ?>
		</p>

		<p class="prod-li-quick-view">
			<a href="#" class="quick-view" data-id="<?php echo get_the_ID(); ?>" title="<?php esc_attr_e('Quick View', 'motor'); ?>"><span class="quick-view-inner"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="5" y="5" width="6" height="6" rx="1" stroke="#858DAA" stroke-width="2"/><path d="M1 9V13C1 14.1046 1.89543 15 3 15H7" stroke="#858DAA" stroke-width="2"/><path d="M15 7L15 3C15 1.89543 14.1046 1 13 1L9 1" stroke="#858DAA" stroke-width="2"/></svg><span><?php esc_html_e('Quick View', 'motor'); ?></span></span></a>
			<i class="fa fa-spinner fa-pulse quick-view-loading"></i>
		</p>

		<?php
		if ( class_exists( 'YITH_WCWL' ) ) {
			echo do_shortcode('[yith_wcwl_add_to_wishlist]');
		}
		?>

		<?php motor_show_compare_btn(); ?>

	</div>

	<?php motor_product_badge(get_the_ID(), 'prod-li-badge'); ?>

	</div>

	<?php motor_list_info(); ?>

</article>
<?php
$int_key++;
?>