<?php
/**
 * The template for displaying all single posts.
 */
get_header();

global $motor_options;



$project_position = get_post_meta(get_the_ID(), 'motor_project_position', true);
$project_width = get_post_meta(get_the_ID(), 'motor_project_width', true);
$project_width_img = get_post_meta(get_the_ID(), 'motor_project_width_img', true);
$project_type = get_post_meta(get_the_ID(), 'motor_project_type', true);
if (!empty($project_position)) {
    $motor_options['projects_position'] = $project_position;
}
if (!empty($project_width)) {
    $motor_options['projects_width'] = $project_width;
}
if (!empty($project_width_img)) {
    $motor_options['projects_width_img'] = $project_width_img;
}
if (!empty($project_type)) {
    $motor_options['projects_type'] = $project_type;
}
?>

<?php if (have_posts()) : ?>
<?php while ( have_posts() ) : the_post();

    if ($motor_options['projects_position'] == 'before_title') {
        get_template_part('template-parts/project-gallery');
    }

    motor_title_block_render('normal-project');

    if ($motor_options['projects_position'] == 'after_title') {
        get_template_part('template-parts/project-gallery');
    }

    $is_elementor = get_post_meta(get_the_ID(), '_elementor_edit_mode', true);
    if (!empty($is_elementor) && $is_elementor == 'builder') {
        $post_width = 'full';
    } else {
        $post_width = 'container';
    }
    ?>


    <?php
    if ($motor_options['projects_position'] == 'aside') {
        echo '<div class="'.(($motor_options['projects_width'] == 'container') ? 'container ' : '').'project-item-wrapper">';
        echo '<div id="cont-sb-sticky" class="project-item-sb">';
        echo '<div class="theiaStickySidebar">';
        get_template_part('template-parts/project-gallery');
        echo '</div>';
        echo '</div>';
        echo '<div id="cont-content-sticky" class="project-item-content">';
        echo '<div class="theiaStickySidebar">';
    }
    ?>


    <?php
    if ($post_width == 'full') {
    ?>
    <section id="<?php echo get_the_ID(); ?>" <?php post_class(array('site-content', 'project-item', 'maincont', 'page-styling', 'page-full')); ?>>
    <?php
    } else {
    ?>
    <article id="<?php echo get_the_ID(); ?>" <?php post_class(array('site-content', 'container', 'maincont', 'project-item', 'page-styling')); ?>>
    <?php
    }

    $info = array();
    $info_meta = get_post_meta(get_the_ID(), 'motor_project_info', true);
    if (!empty($info_meta['value'])) {
        foreach ($info_meta['value'] as $key=>$value) {
            $info[$key]['value'] = $value;
            if (!empty($info_meta['label'][$key])) {
                $info[$key]['label'] = $info_meta['label'][$key];
            } else {
                $info[$key]['label'] = '';
            }
        }
    }

    if (!empty($info) && !empty($info['0']['value']) && !empty($info['0']['label'])) {
        if ($post_width == 'full') {
            echo '<div class="container">';
        }
        ?>
        <ul class="project-item-info">
            <?php
            foreach($info as $info_item) {
                ?>
                <li>
                    <b><?php echo esc_html($info_item['label']); ?></b>
                    <span><?php echo esc_html($info_item['value']); ?></span>
                </li>
                <?php
            }
            ?>
        </ul>
        <?php
        if ($post_width == 'full') {
            echo '</div>';
        }
    }


    if ($post_width == 'full') {
        the_content();
    } else {
        ?>
        <div class="page-cont">
        <?php
        the_content();

        echo '<div class="project-item-share">';
        wp_link_pages( array(
            'before'           => '<p class="link-pages">',
            'after'            => '</p>',
            'link_before'      => '<span>',
            'link_after'       => '</span>',
            'nextpagelink'     => '<i class="fa fa-angle-right"></i>',
            'previouspagelink' => '<i class="fa fa-angle-left"></i>',
        ) );

        // Social Share
        if (!empty($motor_options['blog_share'])) {
            get_template_part('template-parts/share');
        }
        echo '</div>';

        if ( (comments_open() || get_comments_number()) && $motor_options['projects_position'] !== 'aside' ) {
            comments_template();
        }
        ?>
        </div>
        <?php
    }


    if ($post_width == 'full') {
        ?>
        </section>
        <?php
    } else {
        ?>
        </article>
        <?php
    }
    ?>


    <?php
    if ($motor_options['projects_position'] == 'aside') {
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    ?>


    <?php
    if ($motor_options['projects_position'] == 'after_content') {
        get_template_part('template-parts/project-gallery');
    }
    ?>



    <?php
    // If comments are open or we have at least one comment, load up the comment template.
    if ((comments_open() || get_comments_number()) && ($post_width == 'full' || $motor_options['projects_position'] == 'aside')) {
        echo '<div class="maincont project-item-comments-wrap">';
        echo '<div class="cont">';
        comments_template();
        echo '</div>';
        echo '</div>';
    }
    ?>




    <?php
    $next_post = get_next_post();
    $prev_post = get_previous_post();
    if (!empty($next_post) || !empty($prev_post)) : ?>
        <ul class="project-pg-nav<?php if (empty($next_post) || empty($prev_post)) echo ' project-pg-nav-single'; ?>">
            <?php if (!empty($prev_post)) :
                $prev_post_img = wp_get_attachment_image_src(get_post_thumbnail_id($prev_post), 'large');
                ?>
                <li class="project-pg-nav-prev">
                    <a href="<?php echo get_permalink($prev_post->ID); ?>">
                        <div class="project-pg-nav-img"<?php if (!empty($prev_post_img[0])) : ?> style="background-image: url(<?php echo $prev_post_img[0]; ?>);"<?php endif; ?>></div>
                        <h3><?php echo esc_attr($prev_post->post_title); ?> <i class="ion ion-ios-arrow-left"></i></h3>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (!empty($next_post)) :
                $next_post_img = wp_get_attachment_image_src(get_post_thumbnail_id($next_post), 'large');
                ?>
                <li class="project-pg-nav-next">
                    <a href="<?php echo get_permalink($next_post->ID); ?>">
                        <div class="project-pg-nav-img"<?php if (!empty($next_post_img[0])) : ?> style="background-image: url(<?php echo $next_post_img[0]; ?>);"<?php endif; ?>></div>
                        <h3><?php echo esc_attr($next_post->post_title); ?> <i class="ion ion-ios-arrow-right"></i></h3>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>



<?php endwhile; ?>
<?php endif; ?>

<?php
get_footer();
