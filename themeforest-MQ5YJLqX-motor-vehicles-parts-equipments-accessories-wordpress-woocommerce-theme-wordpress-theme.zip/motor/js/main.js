"use strict";


function motor_create_line(x1, y1, x2, y2, after_el) {
    var length = Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
    var angle  = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
    var transform = 'rotate('+angle+'deg)';

    var line = jQuery('<div>').insertAfter(after_el).addClass('line').css({
        'position': 'absolute',
        'transform': transform
    }).offset({left: x1, top: y1}).width(length);
    return line;
}

function motor_initslider(refresh, parent) {

	var slider_thumbs = '#prod-thumbs';
	var slider_main = '#prod-slider';

	if (refresh) {
		jQuery('#prod-thumbs').removeData("flexslider");
		jQuery('#prod-thumbs .slides').find("li").off();
		jQuery('#prod-slider').removeData("flexslider");
		var slides_html = jQuery('#prod-slider .slides').html();
		jQuery('#prod-slider .slides').html(slides_html);
	}

	if (parent) {
		slider_thumbs = parent + ' ' + slider_thumbs;
		slider_main = parent + ' ' + slider_main;
	}

	jQuery(slider_thumbs).flexslider({
		animation: "slide",
		controlNav: false,
		animationLoop: false,
		slideshow: false,
		itemWidth: 97,
		itemMargin: 0,
		minItems: 4,
		maxItems: 4,
		asNavFor: slider_main,
		start: function(slider){
			jQuery(slider_thumbs).resize();
		}
	});
	jQuery(slider_main).flexslider({
		animation: "fade",
		animationSpeed: 500,
		slideshow: false,
		animationLoop: false,
		smoothHeight: false,
		controlNav: false,
		sync: slider_thumbs,
	});
}
function motor_get_cookie(name) {
	var matches = document.cookie.match(new RegExp(
		"(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
	));
	return matches ? decodeURIComponent(matches[1]) : undefined;
}
function motor_in_array(needle, haystack, strict) {
	var found = false, key, strict = !!strict;
	for (key in haystack) {
		if ((strict && haystack[key] === needle) || (!strict && haystack[key] == needle)) {
			found = true;
			break;
		}
	}
	return found;
}


// WooCommerce Ajax Cart
function motor_ajax_cart(element) {
    var form = element.closest('form');

	// emulates button Update cart click
    jQuery("<input type='hidden' name='update_cart' id='update_cart' value='1'>").appendTo(form);

	// plugin flag
    jQuery("<input type='hidden' name='is_wac_ajax' id='is_wac_ajax' value='1'>").appendTo(form);

    var el_qty = element;
    var matches = element.attr('name').match(/cart\[(\w+)\]/);
    var cart_item_key = matches[1];
    form.append( jQuery("<input type='hidden' name='cart_item_key' id='cart_item_key'>").val(cart_item_key) );

	// when qty is set to zero, then fires default woocommerce remove link
    if ( el_qty.val() == 0 ) {
        var removeLink = element.closest('.cart_item').find('.product-remove a');
        removeLink.click();

        return false;
    }

	// get the form data before disable button...
    var formData = form.serialize();

    jQuery("a.checkout-button.wc-forward").addClass('disabled');

    jQuery.post( form.attr('action'), formData, function(resp) {
    	jQuery('.cart-subtotal').html(jQuery(resp).find('.cart-subtotal').html());
    	jQuery('.order-total').html(jQuery(resp).find('.order-total').html());
    	jQuery('.section-count').html(jQuery(resp).find('.section-count').html());

        jQuery('#update_cart').remove();
        jQuery('#is_wac_ajax').remove();
        jQuery('#cart_item_key').remove();

        jQuery("a.checkout-button.wc-forward").removeClass('disabled');

		// fix to update "Your order" totals when cart is inside Checkout page
        if ( jQuery( '.woocommerce-checkout' ).length ) {
            jQuery( document.body ).trigger( 'update_checkout' );
        }

        jQuery( document.body ).trigger( 'updated_cart_totals' );
    });

    return true;
}






function number_format (number, decimals, dec_point, thousands_sep) {
	number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
	var n = !isFinite(+number) ? 0 : +number,
		prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
		sep = (typeof thousands_sep === 'undefined') ? '' : thousands_sep,
		dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
		s = '',
		toFixedFix = function (n, prec) {
			var k = Math.pow(10, prec);
			return '' + Math.round(n * k) / k;
		};
	// Fix for IE parseFloat(0.55).toFixed(0) = 0;
	s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
	if (s[0].length > 3) {
		s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
	}
	if ((s[1] || '').length < prec) {
		s[1] = s[1] || '';
		s[1] += new Array(prec - s[1].length + 1).join('0');
	}
	return s.join(dec);
}

jQuery(document).ready(function ($) {

	// Sticky sidebar
	if ($('#section-sb').length > 0 && $('#section-list-withsb').length > 0) {
		$('#section-sb, #section-list-withsb').theiaStickySidebar({
			additionalMarginTop: 30
		});
	}
	if ($('#cont-sb-sticky').length > 0 && $('#cont-content-sticky').length > 0) {
		$('#cont-sb-sticky, #cont-content-sticky').theiaStickySidebar({
			additionalMarginTop: 30
		});
	}


	// Select Styler
	if ($('.blog-sb-widget:not(.WOOF_Widget) select').length > 0) {
		$('.blog-sb-widget:not(.WOOF_Widget) select').chosen({
			disable_search_threshold: 10
		});
	}
	if ($('.shipping-calculator-form select').length > 0) {
		$('.shipping-calculator-form select').chosen({
			disable_search_threshold: 10
		});
	}


    // Preloader
    if ($('#site-preloader').length > 0) {
        $(window).on('load', function() {
			if ($('body').hasClass('site-preloader-show')) {
				$('body').removeClass('site-preloader-show');
				$('#site-preloader').fadeOut();
			}
        });
		setTimeout(function () {
			if ($('body').hasClass('site-preloader-show')) {
				$('body').removeClass('site-preloader-show');
				$('#site-preloader').fadeOut();
			}
		}, 5000);
    }

});



(function($) {
	jQuery(window).on('load', function(){


		// Modal Form
		$('.callback').fancybox({
			padding: 0,
			content: $('#modal-form'),
			helpers: {
				overlay: {
					locked: false
				}
			},
			tpl: {
				closeBtn: '<a title="Close" class="fancybox-item fancybox-close modal-form-close" href="javascript:;"></a>'
			}
		});

		// Modal Form - Request Product
		$('.request-form-btn').fancybox({
			padding: 0,
			content: $('#request-form'),
			helpers: {
				overlay: {
					locked: false
				}
			},
			tpl: {
				closeBtn: '<a title="Close" class="fancybox-item fancybox-close modal-form-close" href="javascript:;"></a>'
			}
		});


		// Fancybox Images
		$('.fancy-img').fancybox({
			padding: 0,
			margin: [60, 50, 20, 50],
			helpers: {
				overlay: {
					locked: false
				},
				thumbs: {
					width: 60,
					height: 60
				}
			},
			tpl: {
				closeBtn: '<a title="Close" class="fancybox-item fancybox-close modal-form-close2" href="javascript:;"></a>',
				prev: '<a title="Previous" class="fancybox-nav fancybox-prev modal-prev" href="javascript:;"><span></span></a>',
				next: '<a title="Next" class="fancybox-nav fancybox-next modal-next" href="javascript:;"><span></span></a>',
			}
		});

		// Modal Videos
		/*$(".motor-gallery").on('click', ".motor-gallery-video", function() {
			$.fancybox({
				'padding'       : 0,
				'autoScale'     : false,
				'transitionIn'  : 'none',
				'transitionOut' : 'none',
				'href'          : this.href.replace(new RegExp("watch\\?v=", "i"), 'v/'),
				'type'          : 'swf',
				'swf'           : {
					'wmode'             : 'transparent',
					'allowfullscreen'   : 'true'
				},
				tpl: {
					closeBtn: '<a title="Close" class="fancybox-item fancybox-close modal-form-close2" href="javascript:;"></a>'
				}
			});
			return false;
		});*/



		// Dropdown
		if ($('.dropdown-wrap').length > 0) {
			$('.dropdown-wrap').on('click', '.dropdown-title', function () {
				$('.dropdown-list').slideUp(200);
				if ($(this).hasClass('opened')) {
					$(this).removeClass('opened');
				} else {
					$('.dropdown-wrap .dropdown-title').removeClass('opened');
					$(this).addClass('opened');
					$(this).next('.dropdown-list').slideDown(200);
				}
				return false;
			});
			$('.dropdown-wrap .dropdown-list li').on('click', 'a', function () {
				$(this).closest('.dropdown-wrap').find('.dropdown-title').text($(this).text());
				if ($(this).data('value')) {
					var per_page_select = $(this).parents('.products-per-page').find('select');
					var per_page_val = $(this).data('value');
					per_page_select.val(per_page_val).trigger('change');
					$('.dropdown-list').slideUp(200);
					$('.dropdown-wrap .dropdown-title').removeClass('opened');
					return false;
				}
			});
		}

		if ($('.dropdown-wrap').length > 0) {
			$('body').on('click', function () {
				if ($('.dropdown-wrap').length > 0) {
					$('.dropdown-list').slideUp(200);
					$('.dropdown-wrap .dropdown-title').removeClass('opened');
				}
			});
		}



		// Top Menu Seacrh
		$('.header').on('click', '#header-searchbtn', function () {
			if ($(this).hasClass('opened')) {
				$(this).removeClass('opened');
				/*$('#header-search').hide();*/
			} else {
				$(this).addClass('opened');
				/*$('#header-search').show();*/
			}
			return false;
		});


		// Top Menu
		$('.header').on('click', '#header-menutoggle', function () {
			if ($(this).hasClass('opened')) {
				$(this).removeClass('opened');
				$('#top-menu').fadeOut();
			} else {
				$(this).addClass('opened');
				$('#top-menu').fadeIn();
			}
			return false;
		});
		// Top SubMenu
		$('#top-menu').on('click', '.menu-item-has-children > a', function () {
			if ($(window).width() <= 768) {
				if ($(this).hasClass('opened')) {
					$(this).removeClass('opened');
					$(this).parent().find('> ul').slideUp();
				} else {
					$(this).addClass('opened');
					$(this).parent().find('> ul').slideDown();
				}
				return false;
			}
		});





		// Top Menu - Toggle Button
		$(document).on('click', '.el-menu-mobile-btn', function () {
			var $body = $('body'),
				$nav = $('#' + $(this).data('menu-id'));

			if ($nav.data('moved') !== 'yes') {
				$body.append($nav);
				$nav.show().attr('data-moved', 'yes');
				$body.addClass('menu-opened');
			} else if ($body.hasClass('menu-opened')) {
				$body.removeClass('menu-opened');
			} else {
				$body.addClass('menu-opened');
			}

			if ($body.hasClass('menu-opened')) {
				$body.append('<div class="el-menu-overlay" id="el-menu-overlay"></div>');

				var window_height = $(window).height();
				var items_count = $nav.find('> ul > li').length;
				var items_height = Math.max((window_height-200)/items_count, 45);
				items_height = Math.min(items_height, 85);
				$nav.find('> ul > li > a').each(function () {
					var item_height = $(this).height();
					var item_margin = items_height - item_height;
					$(this).css('padding-top', Math.round(item_margin/2));
					$(this).css('padding-bottom', Math.round(item_margin/2));
				});
			}
			return false;
		});
		$(document).on('click', '.el-menu-mobile-close', function () {
			$('#el-menu-overlay').remove();
			$('body').removeClass('menu-opened');
		});
		$(document).on('click', 'body.menu-opened', function () {
			$('#el-menu-overlay').remove();
			$('body').removeClass('menu-opened');
		});
		$(document).on('click', '.el-menu-mobile', function(event){
			event.stopPropagation();
		});


		// Top Menu Links - Equilize Height
		if ($(window).width() > 751) { // 768
			$('.el-menu-mobile > ul > li.menu-item-has-children')
				.on( "mouseenter", function() {
					var window_height = $(window).height();
					var sub_items_count = $(this).find('> ul > li').length;
					var sub_items_height = Math.max((window_height-100)/sub_items_count, 40);
					sub_items_height = Math.min(sub_items_height, 85);
					var max_margin = 0;

					$(this).find('> ul').fadeIn(200);

					$(this).find('> ul > li').each(function () {
						var item_height = $(this).height();
						var item_margin = sub_items_height - item_height;
						max_margin = Math.max(item_margin, max_margin);
						$(this).css('margin-bottom', Math.round(max_margin));
					});
				})
				.on( "mouseleave", function() {
					$(this).find('> ul').fadeOut(200);
				});
		}
		$(window).resize(function () {
			if ($(window).width() > 751) { // 768
				$('.el-menu-mobile > ul > li.menu-item-has-children')
					.on( "mouseenter", function() {
						var window_height = $(window).height();
						var sub_items_count = $(this).find('> ul > li').length;
						var sub_items_height = Math.max((window_height-100)/sub_items_count, 40);
						sub_items_height = Math.min(sub_items_height, 85);
						var max_margin = 0;

						$(this).find('> ul > li').each(function () {
							var item_height = $(this).height();
							var item_margin = sub_items_height - item_height;
							max_margin = Math.max(item_margin, max_margin);
							$(this).css('margin-bottom', Math.round(item_margin));
						});

						$(this).find('> ul').fadeIn(200);
					})
					.on( "mouseleave", function() {
						$(this).find('> ul').fadeOut(200);
					});
			} else {
				$('.el-menu-mobile > ul > li.menu-item-has-children').off("mouseenter");
				$('.el-menu-mobile > ul > li.menu-item-has-children').off("mouseleave");
			}
		});
		$('.el-menu-mobile > ul li.menu-item-has-children > a').each(function () {
			$(this).append('<i class="fa fa-angle-down"></i>');
		});
		$('.el-menu-mobile > ul li.menu-item-has-children > a > .fa').on('click', function () {
			if ($(this).parent().parent().hasClass('opened')) {
				$(this).parent().parent().removeClass('opened');
				$(this).parent().next('ul').slideUp();
			} else {
				$(this).parent().next('ul').slideDown();
				$(this).parent().parent().addClass('opened');
			}
			return false;
		});



		// Mega Menu "Content" Width
		if ($('.mega-menu-width-content').length > 0) {
			$('.mega-menu-width-content').on( "mouseenter", function() {
				var $this = $(this),
					$window = $(window),
					$body = $('body'),
					$width = 1190,
					$left,
					$elementor = $this.find('> .elementor');

				if ($window.width() < 559) { // 576
					$width = 320;
				} else if ($window.width() < 751) { // 768
					$width = 540;
				} else if ($window.width() < 975) { // 992
					$width = 720;
				} else if ($window.width() < 1233) { // 1250
					$width = 960;
				}

				if ($elementor.length) {
					$elementor.css('width', $width + 'px');
					$left = $body.width()/2 - $width/2 - $this.offset().left;
					if ($width + $left < 0) {
						$left += $this.width() - ($left + $width);
					} else if ($left > 0) {
						$elementor.css('margin-left', '-10px');
						return;
					}
					$elementor.css('margin-left', $left + 'px');
				}
			});
		}

		// Mega Menu "Full" Width
		if ($('.mega-menu-width-full').length > 0) {
			$('.mega-menu-width-full').on( "mouseenter", function() {
				var $this = $(this),
					$window = $(window),
					$body = $('body'),
					$width = $body.width(),
					$left,
					$elementor = $this.find('> .elementor');

				if ($elementor.length) {
					$elementor.css('width', $width + 'px');
					$left = - $this.offset().left;
					$elementor.css('margin-left', $left + 'px');
				}
			});
		}



		// Section Menu
		if ($('#section-menu-btn').length > 0) {
			$('.section-top').on('click', '#section-menu-btn', function () {
				if ($(this).hasClass('opened')) {
					$(this).removeClass('opened').html($(this).data('showtext'));
					$('#section-menu-wrap').fadeOut(200);
					$('.section-menu-overlay').fadeOut(200).remove();
				} else {
					$(this).addClass('opened').width($(this).width()).html($(this).data('hidetext'));
					$('#section-menu-wrap').fadeIn(200);
					$('body').append('<div class="section-menu-overlay"></div>');
					$('.section-menu-overlay').fadeIn(200);

					$('body').on('click', '.section-menu-overlay', function () {
						$('#section-menu-btn').removeClass('opened').html($('#section-menu-btn').data('showtext'));
						$('#section-menu-wrap').fadeOut(200);
						$('.section-menu-overlay').fadeOut(200).remove();
						return false;
					});
				}
				return false;
			});

			$('.section-top #section-menu-wrap > ul > li > ul > li > a').on('click', function () {
				var link = $(this);
				var parent = link.parent();
				var child = parent.find('> ul');
				if (child.length > 0 && !link.hasClass('opened')) {
					$('.section-menu-wrap a').removeClass('opened');
					link.addClass('opened');
					$('.section-menu-wrap > ul > li > ul > li > ul').slideUp();
					child.slideToggle();
					return false;
				}
			});
		}


		// Filter Button
		if ($('#section-filter-toggle-btn').length > 0 && $('#section-filter .woof_redraw_zone').length > 0) {
			$('.section-filter-toggle').on('click', '#section-filter-toggle-btn', function () {
				if ($(this).parent().hasClass('filter_hidden')) {
					$(this).text($(this).data('hidetext')).parent().removeClass('filter_hidden');
					//$('#section-filter .woof_redraw_zone').slideDown();
					document.cookie = "filter_toggle=filter_opened; expires=Thu, 31 Dec 2020 23:59:59 GMT; path=/;";
				} else {
					$(this).text($(this).data('showtext')).parent().addClass('filter_hidden');
					//$('#section-filter .woof_redraw_zone').slideUp();
					document.cookie = "filter_toggle=filter_hidden; expires=Thu, 31 Dec 2020 23:59:59 GMT; path=/;";
				}

				return false;
			});
		}





        // Content Tabs
        $('body').on('click', 'a[data-prodtab]', function () {
            var $this = $(this);
            var $wrap = $(this).parents('div[data-prodtab-wrap]');
            if ($this.hasClass('active') || $this.attr('data-prodtab') == '')
                return false;

            $wrap.find('a[data-prodtab]').removeClass('active');
            $this.addClass('active');

            // mobile
            $wrap.find('[data-prodtab-mob]').removeClass('active');
            $wrap.find('[data-prodtab-mob=' + $this.data('prodtab') + ']').addClass('active');

            $wrap.find('[data-prodtab-cont]').css('height', '0px');
            $wrap.find($this.attr('data-prodtab')).css('height', 'auto');
            return false;
        });

        // Content Tabs (mobile)
        $('body').on('click', '[data-prodtab-mob]', function () {
            var $this = $(this);
            var $wrap = $(this).parents('div[data-prodtab-wrap]');
            if ($this.hasClass('active') || $this.attr('data-prodtab-mob') == '')
                return false;
            $wrap.find('[data-prodtab-mob]').removeClass('active');
            $this.addClass('active');

            // main
            $wrap.find('a[data-prodtab]').removeClass('active');
            $wrap.find('a[data-prodtab=' + $this.data('prodtab') + ']').addClass('active');

            $wrap.find('[data-prodtab-cont]').css('height', '0px');
            $wrap.find($this.attr('data-prodtab-mob')).css('height', 'auto');
            return false;
        });


		// Product Tabs
		$('body').on('click', '.prod-tabs li a', function () {
			if ($(this).parent().hasClass('prod-tabs-addreview') || $(this).parent().hasClass('active') || $(this).attr('data-prodtab') == '')
				return false;
			$('.prod-tabs li').removeClass('active');
			$(this).parent().addClass('active');

			// mobile
			$('.prod-tab-mob').removeClass('active');
			$('.prod-tab-mob[data-prodtab-num=' + $(this).parent().data('prodtab-num') + ']').addClass('active');

			$('.prod-tab-cont .prod-tab').hide();
			$($(this).attr('data-prodtab')).fadeIn();

			return false;
		});

		// Product Tabs (mobile)
		$('body').on('click', '.prod-tab-cont .prod-tab-mob', function () {
			if ($(this).hasClass('active') || $(this).attr('data-prodtab') == '')
				return false;
			$('.prod-tab-cont .prod-tab-mob').removeClass('active');
			$(this).addClass('active');

			// main
			$('.prod-tabs li').removeClass('active');
			$('.prod-tabs li[data-prodtab-num=' + $(this).data('prodtab-num') + ']').addClass('active');

			$('.prod-tab-cont .prod-tab').slideUp();
			$($(this).attr('data-prodtab')).slideDown();
			return false;
		});

		$('body').on('click', '.prod-tabs-addreview', function () {
			if ($('.prod-tabs li.active').attr('id') == 'prod-reviews') {
				$('html, body').animate({scrollTop: ($('.prod-tabs-wrap').offset().top - 10)}, 700);
			} else {
				$('.prod-tabs li').removeClass('active');
				$('.prod-tab-cont .prod-tab-mob').removeClass('active');
				$('#prod-reviews').addClass('active');
				$('.prod-tab-mob-reviews').addClass('active');

				$('.prod-tab-cont .prod-tab').hide();
				$('.prod-tab-cont .prod-tab.prod-reviews').fadeIn();
				$('html, body').animate({scrollTop: ($('.prod-tabs-wrap').offset().top - 10)}, 700);
			}

			$('#review_form_wrapper').fadeIn();

			return false;
		});

		if ($('.prod-tab #commentform #submit').length > 0) {
			var filterEmail  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,6})+$/;
			$('body').on('click', '.prod-tab #commentform #submit', function () {
				var errors = false;
				if (!$(this).parents('#commentform').find('#rating').val()) {
					$('.prod-tab-addreview').addClass('error');
					errors = true;
				}
				$(this).parents('#commentform').find('input[type=text], input[type=email], textarea').each(function () {
					if ($(this).attr('id') == 'email'){
						if (!filterEmail.test($(this).val())) {
							$(this).addClass("redborder");
							errors++;
						}
						else {
							$(this).removeClass("redborder");
						}
						return;
					}
					if ($(this).val() == '') {
						$(this).addClass('redborder');
						errors++;
					} else {
						$(this).removeClass('redborder');
					}
				});

				if (errors)
					return false;
			});
		}

		// Show Properties
		$('.prod-cont').on('click', '#prod-showprops', function () {
			var space = 10;
			if ($('.header.header_sticky').length) {
				var space = $('.header.header_sticky').outerHeight() + 10;
			}
			if ($('.prod-tabs li.active').attr('id') == 'prod-props') {
				$('html, body').animate({scrollTop: ($('.prod-tabs-wrap').offset().top - space)}, 700);
			} else {
				$('.prod-tabs li').removeClass('active');
				$('#prod-props').addClass('active');
				$('.prod-tab-cont .prod-tab').hide();
				$('#prod-tab-2').fadeIn();
				$('html, body').animate({scrollTop: ($('.prod-tabs-wrap').offset().top - space)}, 700);
			}
			return false;
		});

		// Show Description
		$('.prod-cont').on('click', '#prod-showdesc', function () {
			var space = 10;
			if ($('.header.header_sticky').length) {
				var space = $('.header.header_sticky').outerHeight() + 10;
			}
			if ($('.prod-tabs li.active').attr('id') == 'prod-desc') {
				$('html, body').animate({scrollTop: ($('.prod-tabs-wrap').offset().top - space)}, 700);
			} else {
				$('.prod-tabs li').removeClass('active');
				$('#prod-desc').addClass('active');
				$('.prod-tab-cont .prod-tab').hide();
				$('#prod-tab-1').fadeIn();
				$('html, body').animate({scrollTop: ($('.prod-tabs-wrap').offset().top - space)}, 700);
			}
			return false;
		});



		// Post Add Comment Form
		$('.post-comments').on('click', '#post-comments-add', function () {
			$('#post-addcomment-form').slideDown();
			return false;
		});


		// Events
		/*if ($("#blog-calendar").length > 0) {
			if (typeof eventData !== "undefined") {
				$("#blog-calendar").zabuto_calendar({
					action: function () {
						return myDateFunction(this.id);
					},
					today: true,
					nav_icon: {
						prev: '<i class="fa fa-caret-left"></i>',
						next: '<i class="fa fa-caret-right"></i>'
					},
					data: eventData,
				});
			}
		}*/


		// AJAX pagination scroll
		$('body.archive.woocommerce').on('click', 'ul.page-numbers a.page-numbers', function () {
			if ($('#woof_results_by_ajax').length > 0) {
				$('html, body').animate({scrollTop: $('#woof_results_by_ajax').offset().top - 30}, 800);
			}
		});


		// Product List Show Information
		$('body').on('click', '.prod-li-infobtn', function () {
			var product_info = $(this).parents('.prod-li').find('.prod-li-informations');
			$(this).toggleClass('opened');
			if (product_info.length) {
				product_info.slideToggle();
			}
			return false;
		});


		// Update Compare Count & Active Classes
		var compare_list = motor_get_cookie("compare-list");
		if (typeof compare_list !== 'undefined' && compare_list != '') {
			var compare_list_arr = compare_list.split(':');
			compare_list_arr.pop();

			if (compare_list_arr.length > 0 && $('.header-compare').length > 0) {
				if ($('#h-compare-count').length > 0) {
					$('#h-compare-count').text(compare_list_arr.length);
				} else {
					$('.header-compare').append('<span id="h-compare-count">' + compare_list_arr.length + '</span>');
				}
			} else if (compare_list_arr.length === 0 && $('#h-compare-count').length > 0) {
				$('#h-compare-count').text(compare_list_arr.length);
			}
			if ($('#h-personal-compare-count').length > 0) {
				$('#h-personal-compare-count').text(compare_list_arr.length);
			}

			$('.prod-li-compare-btn').each(function () {
				if ($(this).hasClass('prod-li-compare-added') && !motor_in_array($(this).data('id'), compare_list_arr)) {
					$(this).removeClass('prod-li-compare-added').attr('href', $(this).data('url'));
					$(this).text($(this).data('text'));
				} else if (!$(this).hasClass('prod-li-compare-added') && motor_in_array($(this).data('id'), compare_list_arr)) {
					$(this).addClass('prod-li-compare-added').attr('href', $(this).data('url'));
					$(this).text($(this).data('text'));
				}
			});
		}

		// Update WishList Count & Active Classes
		var wishlist_list = motor_get_cookie("yith_wcwl_products");
		if (typeof wishlist_list !== 'undefined' && wishlist_list != '') {
			var wishlist_list_obj = $.parseJSON(wishlist_list);
			var wishlist_list_ids = [];

			for(var wishlist_item in wishlist_list_obj) {
				wishlist_list_ids[wishlist_list_ids.length] = wishlist_list_obj[wishlist_item]['prod_id'];
			}

			if (wishlist_list_ids.length > 0 && $('.header-favorites').length > 0) {
				if ($('#h-wishlist-count').length > 0) {
					$('#h-wishlist-count').text(wishlist_list_ids.length);
				} else {
					$('.header-favorites').append('<span id="h-wishlist-count">' + wishlist_list_ids.length + '</span>');
				}
			} else if (wishlist_list_ids.length === 0 && $('#h-wishlist-count').length > 0) {
				$('#h-wishlist-count').text(wishlist_list_ids.length);
			}
			if ($('#h-personal-wishlist-count').length > 0) {
				$('#h-personal-wishlist-count').text(wishlist_list_ids.length);
			}

			$('.add_to_wishlist').each(function () {
				var prod_id = $(this).data('product-id');
				var el_wrap = $( '.add-to-wishlist-' + prod_id );
				if (el_wrap.hasClass('wishlist-added') && !motor_in_array(prod_id, wishlist_list_ids)) {
					el_wrap.removeClass('wishlist-added');
					el_wrap.find( '.yith-wcwl-add-button' ).show().removeClass('hide').addClass('show');
					el_wrap.find( '.yith-wcwl-wishlistexistsbrowse' ).hide().removeClass('show').addClass('hide');
					el_wrap.find( '.yith-wcwl-wishlistaddedbrowse' ).hide().removeClass('show').addClass('hide');
				} else if (!el_wrap.hasClass('wishlist-added') && motor_in_array(prod_id, wishlist_list_ids)) {
					el_wrap.addClass('wishlist-added');
					el_wrap.find('.yith-wcwl-add-button').hide().removeClass('show').addClass('hide');
					el_wrap.find( '.yith-wcwl-wishlistexistsbrowse' ).show().removeClass('hide').addClass('show');
				}
			});
		}


		// Updating Wishlist Count
		$('body').on('click', '.add_to_wishlist', function () {
			if ($('.header-favorites').length > 0) {
				var favorites_list = $('.header-favorites #h-wishlist-count').text();
				favorites_list++;
				if ($('#h-wishlist-count').length > 0) {
					$('#h-wishlist-count').text(favorites_list);
				} else {
					$('.header-favorites').append('<span id="h-wishlist-count">' + favorites_list + '</span>');
				}
			}
			if ($('#h-personal-wishlist-count').length > 0) {
				var favorites_list_personal = $('#h-personal-wishlist-count').text();
				favorites_list_personal++;
				$('#h-personal-wishlist-count').text(favorites_list_personal);
			}
		});



		// Filter Toggle
		jQuery('body').on('click', '.woof_front_toggle', function () {
			if (jQuery(this).data('condition') == 'opened') {
				jQuery(this).removeClass('woof_front_toggle_opened');
				jQuery(this).addClass('woof_front_toggle_closed');
				jQuery(this).data('condition', 'closed');
				if (woof_toggle_type == 'text') {
					jQuery(this).text(woof_toggle_closed_text);
				} else {
					jQuery(this).find('img').prop('src', woof_toggle_closed_image);
				}
			} else {
				jQuery(this).addClass('woof_front_toggle_opened');
				jQuery(this).removeClass('woof_front_toggle_closed');
				jQuery(this).data('condition', 'opened');
				if (woof_toggle_type == 'text') {
					jQuery(this).text(woof_toggle_opened_text);
				} else {
					jQuery(this).find('img').prop('src', woof_toggle_opened_image);
				}
			}

			jQuery(this).parents('.woof_container_inner').find('.woof_block_html_items').toggleClass('woof_closed_block');
			return false;
		});




		// Product Slider
		if ($('#prod-slider').length > 0) {
			motor_initslider(false, '');
		}

		// Variation Image
		if ($('.prod-info .variations select').length > 0) {
			$('.prod-info .variations select').chosen({
				disable_search_threshold: 10
			});
		}
		if ($('.prod-info2 select').length > 0) {
			$('.prod-info2 select').chosen({
				disable_search_threshold: 10
			});
		}
		$( ".variations_form" ).on( "update_variation_values", function () {
			if ($('.prod-info .variations select').length > 0) {
				$('.prod-info .variations select').trigger("chosen:updated");
			}
			if ($('.prod-info2 select').length > 0) {
				$('.prod-info2 select').trigger("chosen:updated");
			}
		} );
		$( ".variations_form" ).on( "woocommerce_variation_select_change", function () {
			if ($('.prod-info .variations select').length > 0) {
				$('.prod-info .variations select').trigger("chosen:updated");
			}
			if ($('.prod-info2 select').length > 0) {
				$('.prod-info2 select').trigger("chosen:updated");
			}
			if ($('.prod-varimg').length) {
				$('.prod-varimg').parents('li').remove();
				motor_initslider(true, '');
			}

			if ($('.variations_form .prod-info .prod-price').length > 0 && $('.variations_form .prod-info .prod-price').hasClass('hidden')) {
				$('.variations_form .prod-info .prod-price').removeClass('hidden');
				$('.woocommerce-variation.single_variation').hide();
			}
		} );
		$( ".variations_form" ).on( "found_variation", function ( event, variation ) {
			var img_exists = false;
			if ($('#prod-slider .slides a[href="' + variation.image.full_src + '"]').length > 0) {
				img_exists = true;
			}

			if ($('.variations_form .prod-info .prod-price').length > 0 && !$('.variations_form .prod-info .prod-price').hasClass('hidden')) {
				$('.variations_form .prod-info .prod-price').addClass('hidden');
			}
			//console.log(event);
			//console.log($('#prod-slider .slides a[href="' + variation.image.full_src + '"]').length);
			//console.log(img_exists);
			//console.log(variation);
			if (variation.image_id && !img_exists) {
				if ($('#prod-slider').length) {
					$('#prod-slider .slides').prepend('<li><a data-fancybox-group="prod" class="fancy-img prod-varimg" href="' + variation.image.full_src + '"><img src="' + variation.image.full_src + '" alt=""></a></li>');
					$('#prod-thumbs .slides').prepend('<li><img class="prod-varimg" src="' + variation.image.full_src + '" alt=""></li>');
					motor_initslider(true);
				} else {
					$('.prod-slider-wrap').prepend('<div class="flexslider prod-slider prod-thumb-only" id="prod-slider"><ul class="slides"><li><a data-fancybox-group="prod" class="fancy-img prod-varimg" href="' + variation.image.full_src + '"><img src="' + variation.image.full_src + '" alt=""></a></li></ul></div>');
					motor_initslider(true);
				}
			}/* else if (img_exists && !var_img_exists && variation.variation_id) {
				if (variation.variation_id && variation.image.full_src) {
					console.log(variation.variation_id);
					console.log($('#prod-slider .slides a[href="' + variation.image.full_src + '"]').parent());
					console.log($('#prod-thumbs .slides img[src="' + variation.image.full_src + '"]').parent());
					$('#prod-slider .slides a[href="' + variation.image.full_src + '"]').parent().remove();
					$('#prod-thumbs .slides img[src="' + variation.image.full_src + '"]').parent().remove();
					$('#prod-slider .slides').prepend('<li><a data-fancybox-group="prod" class="fancy-img" href="' + variation.image.full_src + '"><img src="' + variation.image.full_src + '" alt=""></a></li>');
					$('#prod-thumbs .slides').prepend('<li><img src="' + variation.image.full_src + '" alt=""></li>');
					motor_initslider(true);
				}
			}*/
		} );


		if ($('.variations_form .prod-info .prod-price').length > 0) {
			$( ".variations_form" ).trigger( 'woocommerce_variation_select_change' );
			$( ".variations_form" ).trigger( 'check_variations' );
		}



		// Slider "About Us"
		if ($('.content_carousel').length > 0) {
			$('.content_carousel').each(function () {
				if ($(this).data('slideshow_speed') != '') {
					var slideshow_speed =  $(this).data('slideshow_speed');
				} else {
					var slideshow_speed =  '7000';
				}
				if ($(this).data('animation_speed') != '') {
					var animation_speed =  $(this).data('animation_speed');
				} else {
					var animation_speed =  '600';
				}
				if ($(this).data('navigation') == true) {
					var navigation =  true;
				} else {
					var navigation =  false;
				}
				if ($(this).data('pagination') == true) {
					var pagination =  true;
				} else {
					var pagination =  false;
				}
				if ($(this).data('stop_on_hover') == true) {
					var stop_on_hover =  true;
				} else {
					var stop_on_hover =  false;
				}
				$('.content_carousel').flexslider({
					pauseOnHover: stop_on_hover,
					animationSpeed: animation_speed,
					slideshowSpeed: slideshow_speed,
					useCSS: false,
					directionNav: navigation,
					controlNav: pagination,
					animation: "fade",
					slideshow: false,
					animationLoop: true,
					smoothHeight: true
				});
			});
		}


		// Blog sliders
		if ($('.blog-slider').length > 0) {
			$('.blog-slider').flexslider({
				animation: "fade",
				animationSpeed: 500,
				slideshow: false,
				animationLoop: false,
				directionNav: false,
				smoothHeight: false,
				controlNav: true,
			});
		}
		if ($('.post-slider').length > 0) {
			$('.post-slider').flexslider({
				animation: "fade",
				animationSpeed: 500,
				slideshow: false,
				animationLoop: false,
				directionNav: false,
				smoothHeight: true,
				controlNav: true,
			});
		}

		// Slider "Testimonials"
		if ($('.testimonials-car').length > 0) {
			$('.testimonials-car').each(function () {
				var testimonials_slider;
				if ($(this).data('slideshow_speed') != '') {
					var slideshow_speed =  $(this).data('slideshow_speed');
				} else {
					var slideshow_speed =  '7000';
				}
				if ($(this).data('animation_speed') != '') {
					var animation_speed =  $(this).data('animation_speed');
				} else {
					var animation_speed =  '600';
				}
				if ($(this).data('navigation') == true) {
					var navigation =  true;
				} else {
					var navigation =  false;
				}
				if ($(this).data('pagination') == true) {
					var pagination =  true;
				} else {
					var pagination =  false;
				}
				if ($(this).data('stop_on_hover') == true) {
					var stop_on_hover =  true;
				} else {
					var stop_on_hover =  false;
				}
				if ($(this).hasClass('style-1')) {
					var items =  1;
					var item_margin =  0;
				} else {
					var items =  2;
					if ($(window).width() < 751) {
						items =  1;
					}
					var item_margin =  68;
				}
				$(this).flexslider({
					pauseOnHover: stop_on_hover,
					animationLoop: true,
					animation: 'slide',
					animationSpeed: animation_speed,
					slideshowSpeed: slideshow_speed,
					useCSS: false,
					directionNav: navigation,
					controlNav: pagination,
					slideshow: false,
					itemMargin: item_margin,
					itemWidth: 2000,
					maxItems: items,
					minItems: items,
					start: function(slider){
						testimonials_slider = slider;
					}
				});
				$(window).resize(function() {
					if ($(window).width() < 751) {
						testimonials_slider.vars.minItems = 1;
						testimonials_slider.vars.maxItems = 1;
					} else {
						testimonials_slider.vars.minItems = items;
						testimonials_slider.vars.maxItems = items;
					}
				});
			});
		}



		// Quantity
		$('body').on('click change', '.qnt-wrap a, .qnt-wrap input[type=number]', function (e) {
			if (e.type == 'click' && $(this).is('input')) {
				return false;
			}
			var qnt = $(this).parent().find('input').val();
			if ($(this).hasClass('qnt-plus')) {
				qnt++;
			} else if ($(this).hasClass('qnt-minus')) {
				qnt--;
			}
			if (qnt > 0) {
				$(this).parent().find('input').attr('value', qnt);
				if ($(this).parents('.sectls').find('.button').length > 0) {
					$(this).parents('.sectls').find('.button').attr('data-quantity', qnt);
				}
				if ($(this).parents('.prod-cont').find('.button').length > 0) {
					$(this).parents('.prod-cont').find('.button').attr('data-quantity', qnt);
				}
			}

			if (qnt > 0) {

				// Change total price html
				var input = $(this).parent().find('input');
				var prod_price = input.attr('data-qnt-price');
				var prod_qntprice = number_format(qnt*prod_price, input.data('decimals'), input.data('decimal_separator'), input.data('thousand_separator'));
				var prod_qnthtmlprice = input.data('price_format').replace('%2$s', prod_qntprice).replace('%1$s', input.data('currency'));

				if ($(this).parents('.sectls').find('.prod-li-total').length > 0) {
					$(this).parents('.sectls').find('.prod-li-total').html(prod_qnthtmlprice);
				}
				if ($(this).parents('.prod-cont').find('.prod-total-wrap .prod-price').length > 0) {

					$(this).parents('.prod-cont').find('.prod-total-wrap .prod-price').html(prod_qnthtmlprice);

					if ($(this).parents('.prod-cont').find('.prod-add form.cart input.qty').length > 0) {
						$(this).parents('.prod-cont').find('.prod-add form.cart input.qty').val($(this).parent().find('input').attr('value'));
					}

				}
			}

			if ($('.cart-list').length > 0) {
				motor_ajax_cart( $(this).parent().find('.qty') );
			}

			return false;
		});

		if ($('.cart-list').length > 0) {
			$('input.qty').on('keypress', function(e) {
				// Pressing Enter
				if(e.which == 13) {
					var qnt = $(this).parent().find('input').val();
					if (qnt > 0) {
						$(this).parent().find('input').attr('value', qnt);
						motor_ajax_cart( $(this).parent().find('.qty') );
					}
					$(this).trigger('blur');
					return false;
				}
			});
		}



		// Section Product Title in Hover
		$('body')
			.on( "mouseenter", '.prod-items:not(.prod-items-notroll) .prod-i', function() {
				var ttl_height = $(this).find('h3').height();
				var inner_height = $(this).find('h3 span').height();
				$(this).find('h3 span').css('top', (-inner_height+ttl_height));
			})
			.on( "mouseleave", '.special, .popular, .sectgl', function() {
				$(this).find('h3 span').css('top', 0);
			});


		// Masonry Grids
		if ($('#blog-grid').length > 0) {
			$('#blog-grid').isotope({
				itemSelector: '.blog-grid-i',
			});
		}
		if ($('#gallery-grid').length > 0) {

			var $grid = $('#gallery-grid').isotope({
				itemSelector: '.gallery-grid-i',
			});
			$('#gallery-sections').on('click', 'a', function() {
				var filterValue = $( this ).attr('data-section');
				$grid.isotope({ filter: filterValue });
			});
			$('#gallery-sections').each( function( i, buttonGroup ) {
				var $buttonGroup = $( buttonGroup );
				$buttonGroup.on('click', 'a', function() {
					$buttonGroup.find('.active').removeClass('active');
					$( this ).addClass('active');
					return false;
				});
			});

		}
		if ($('.motor-gallery').length > 0) {

			var $grid = $('.motor-gallery').isotope({
				itemSelector: '.gallery-grid-i',
			});
			$('.motor-gallery-sections').on('click', 'a', function() {
				var filterValue = $( this ).attr('data-section');
				$grid.isotope({ filter: filterValue });
			});
			$('.motor-gallery-sections').each( function( i, buttonGroup ) {
				var $buttonGroup = $( buttonGroup );
				$buttonGroup.on('click', 'a', function() {
					$buttonGroup.find('.active').removeClass('active');
					$( this ).addClass('active');
					return false;
				});
			});

		}
		if ($('#about-gallery').length > 0) {
			$('#about-gallery').isotope({
				itemSelector: '.grid-item',
				columnWidth: '.grid-sizer',
				percentPosition: true
			});
		}





		// Ajaxify compare button
		$(document).on( 'click', '.prod-li-compare-btn', function(e){
			e.preventDefault();

			var button = $(this);

			if (button.hasClass('prod-li-compare-added'))
				return false;

			if (!button.hasClass('loading')) {

				button.parent().find('.prod-li-compare-loading').fadeIn();

				$.ajax({
					type: 'post',
					url: $(this).attr('href'),
					success: function(response){

						button.removeClass('loading').addClass('prod-li-compare-added');
						button.parent().find('.prod-li-compare-loading').fadeOut();

						$( '#compare-popup-message' ).remove();
						$( 'body' ).append( '<div id="compare-popup-message">' + button.data('added') + '</div>' );
						$( '#compare-popup-message' ).css( 'margin-left', '-' + $( '#compare-popup-message' ).width() + 'px' ).fadeIn();
						window.setTimeout( function() {
							$( '#compare-popup-message' ).fadeOut();
						}, 2000 );


						// Updating Compare Count
						if ($('#h-compare-count').length > 0) {
							var compare_count = $('#h-compare-count').text();
							compare_count++;
							$('#h-compare-count').text(compare_count);
							if ($('#h-compare-count').length > 0) {
								$('#h-compare-count').text(compare_count);
							}
						} else {
							var compare_count = $('#h-compare-count').text();
							compare_count++;
							$('#h-compare-count').text(compare_count);
							$('.header-compare').append('<span id="h-compare-count">' + compare_count + '</span>');
						}
						if ($('#h-personal-compare-count').length > 0) {
							var compare_count_personal = $('#h-personal-compare-count').text();
							compare_count_personal++;
							$('#h-personal-compare-count').text(compare_count_personal);
						}
					}
				});
			}
		});





		// Masonry Posts
		if ($('.posts-items-masonry').length > 0) {
			$('.posts-items-masonry').each(function () {
				var $this = $(this);
				var $filter = $(this).prev('.posts-items-filter-masonry');
				var $grid = $this.isotope({
					itemSelector: $this.attr('data-item'),
					layoutMode: 'masonry'
				});
				if ($filter.length > 0) {
					$filter.on('click', 'a', function () {
						var filterValue = $(this).attr('data-section');
						$grid.isotope({filter: filterValue});
					});
					$filter.each(function (i, buttonGroup) {
						var $buttonGroup = $(buttonGroup);
						$buttonGroup.on('click', 'a', function () {
							$buttonGroup.find('.active').removeClass('active');
							$(this).parent().addClass('active');
							return false;
						});
					});
				}
			});
		}


		// "Posts" element "Show More" button
		$('.posts-items-more').on('click', function () {
			var button = $(this);
			var container = button.parent().parent().find(button.data('container'));
			var item = button.attr('data-item');
			var page_num = parseInt(button.attr('data-page_num'));
			var max_num_pages = parseInt(button.attr('data-max_num_pages'));
			var file_type = button.attr('data-file-type');
			var post_type = button.attr('data-post_type');
			var order = button.attr('data-order');
			var orderby = button.attr('data-orderby');
			var posts_per_page = button.attr('data-posts_per_page');
			var view_mode = button.attr('data-view_mode');
			var overlay_hover = button.attr('data-overlay_hover');
			var image_size = button.attr('data-image_size');
			var img_ratio = button.attr('data-img_ratio');
			var show_excerpt = button.attr('data-show_excerpt');
			var show_link = button.attr('data-show_link');
			var show_thumbnail = button.attr('data-show_thumbnail');
			var columns = button.attr('data-columns');
			var posts_ids = button.attr('data-posts_ids');
			var pagination = button.attr('data-pagination');
			var show_title = button.attr('data-show_title');
			var show_category = button.attr('data-show_category');
			var show_buttons = button.attr('data-show_buttons');
			var layout = button.attr('data-layout');
			var layout_metro_row = button.attr('data-layout_metro_row');
			var layout_packery_items = button.attr('data-layout_packery_items');
			var content_position = button.attr('data-content_position');

			if (!button.hasClass('loading')) {

				button.addClass('loading');

				$.ajax({
					type: "POST",
					data: {
						page_num: page_num,
						max_num_pages: max_num_pages,
						file_type: file_type,
						post_type: post_type,
						order: order,
						orderby: orderby,
						posts_per_page: posts_per_page,
						view_mode: view_mode,
						overlay_hover: overlay_hover,
						image_size: image_size,
						img_ratio: img_ratio,
						show_excerpt: show_excerpt,
						show_link: show_link,
						show_thumbnail: show_thumbnail,
						columns: columns,
						posts_ids: posts_ids,
						pagination: pagination,
						show_title: show_title,
						show_category: show_category,
						show_buttons: show_buttons,
						content_position: content_position,
						layout: layout,
						layout_metro_row: layout_metro_row,
						layout_packery_items: layout_packery_items,
						nonce: motor_ajax_var.nonce,
						action: 'motor_load_more'
					},
					url: motor_ajax_var.url,
					success: function(data){
						$(button).removeClass('loading');
						if (max_num_pages <= page_num) {
							$(button).remove();
						}
						var posts_list = $(data).find(item);

						if ($(container).hasClass('posts-items-masonry')) {
							$(container).append(posts_list).each(function(){
								$(container).isotope('reloadItems');
							});

							var $grid = $(container).isotope({
								itemSelector: item,
								layoutMode: 'masonry'
							});
							$grid.imagesLoaded().progress(function () {
								$grid.isotope('layout');
							});
						} else {
							$(container).append(posts_list);
						}

						page_num++;
						button.attr('data-page_num', page_num);
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$(button).remove();
						alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
					}
				});
			}
			return false;
		});




		$('.special-more').on('click', '.special-more-btn', function () {
			var button = $(this);
			var max_num_pages = button.attr('data-max-num-pages');
			var page_num = button.attr('data-page-num');
			var posts_per_page = button.attr('data-posts_per_page');
			var catalog_img_carousel = button.attr('data-catalog_img_carousel');
			var container = button.parent().parent().find(button.attr('data-container'));
			var url = button.attr('data-url');
			var file_type = button.attr('data-file-type');
			var order = button.attr('data-order');
			var orderby = button.attr('data-orderby');
			var view_mode = button.attr('data-view-mode');
			var item = button.attr('data-item');
			var ids = button.attr('data-ids');

			if (!button.hasClass('loading')) {

				button.addClass('loading');

				$.ajax({
					type: "POST",
					data: {
						posts_per_page : posts_per_page,
						catalog_img_carousel : catalog_img_carousel,
						page_num: page_num,
						order: order,
						orderby: orderby,
						view_mode: view_mode,
						file_type: file_type,
						posts_ids: ids,
						nonce: motor_ajax_var.nonce,
						action: 'motor_load_more'
					},
					url: motor_ajax_var.url,
					success: function(data){
						$(button).removeClass('loading');
						if (max_num_pages <= page_num) {
							$(button).remove();
						}

						page_num++;
						button.attr('data-page-num', page_num);

						var btn_new = $(data).find('.' + button.attr('class'));
						var posts_list = $(data).find(item);
						container.append(posts_list);
						button.attr('data-max-num-pages', btn_new.attr('data-max-num-pages'));
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$(button).remove();
						alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
					}
				});
			}
			return false;
		});


		$('.cart-actions').on('click', '#shipping-cart-methods tr th', function () {
			if ($(this).hasClass('opened')) {
				$(this).removeClass('opened');
				$('#shipping_method').slideUp();
			} else {
				$(this).addClass('opened');
				$('#shipping_method').slideDown();
			}
			if ($('.shipping-calculator-form').css('display') == 'block') {
				$('.shipping-calculator-form').fadeOut();
			}
			return false;
		});
		if ($('#shipping_method').length > 0) {
			$('#shipping-cart-methods tr th').addClass('dropdown-list');
		}
		$( document.body ).on( 'updated_cart_totals', function() {
			if ($('#shipping_method').length > 0) {
				$('#shipping-cart-methods tr th').addClass('dropdown-list');
			}
		});





		if ($('.cont-sections').length > 0) {
			if ($(window).width() > 1203) {
				var menu_sections = $('.cont-sections');
				var menu_width = menu_sections.width();
				var menu_items_width = 0;
				menu_sections.find('> li').each(function () {
					if (!$(this).hasClass('cont-sections-more')) {
						menu_items_width = menu_items_width + ($(this).outerWidth(true) + 4);
						if (menu_width < menu_items_width) {
							$(this).addClass('cont-sections-other');
							$(this).appendTo('.cont-sections-sub');
						} else if ($(this).hasClass('cont-sections-other')) {
							$(this).removeClass('cont-sections-other');
							$(this).prependTo('.cont-sections-sub');
						}
					}
				});
				if (menu_width < menu_items_width) {
					$('.cont-sections-more').show();
				}
			}

			$('.cont-sections').addClass('sections-show');

			$(window).resize(function() {
				var menu_sections = $('.cont-sections');
				var menu_width = menu_sections.width();
				var menu_items_width = 0;
				if ($(window).width() > 1203) {
					menu_sections.find('> li').each(function () {
						menu_items_width = menu_items_width + ($(this).outerWidth(true) + 4);
						if (!$(this).hasClass('cont-sections-more')) {
							if (menu_width < menu_items_width) {
								$(this).addClass('cont-sections-other');
								$(this).appendTo('.cont-sections-sub');
							} else if ($(this).hasClass('cont-sections-other')) {
								$(this).removeClass('cont-sections-other');
								$(this).prependTo('.cont-sections-sub');
							}
						}
					});
					if (menu_width < menu_items_width) {
						$('.cont-sections-more').show();
					}
				} else {
					menu_sections.find('li.cont-sections-other').insertBefore('.cont-sections-more');
					menu_sections.find('li.cont-sections-other').removeClass('cont-sections-other');
				}
			});

		}




		// Quick View
		$('.maincont').on('click', '.quick-view', function () {
			var button = $(this);
			var product_id = $(this).data('id');
			var url = $(this).data('url');
			if (!button.hasClass('loading')) {

				button.addClass('loading');

				$.ajax({
					type: "POST",
					data: {
						product_id: product_id,
						nonce: motor_ajax_var.nonce,
						action: 'motor_quick_view'
					},
					url: motor_ajax_var.url,
					success: function(data){
						$(button).removeClass('loading');
						$.fancybox({
							content: data,
							padding: 0,
							helpers : {
								overlay : {
									locked  : false
								}
							}
						});

						motor_initslider(false, '.fancybox-wrap .quick-view-modal');

					},
					error: function(jqXHR, textStatus, errorThrown) {
						$(button).remove();
						alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
					}
				});
			}
			return false;
		});


		// Project Quick View
		$('.projects-items').on('click', '[data-project-qview]', function () {
			var button = $(this),
				project_id = $(this).data('project-qview'),
				url = $(this).data('url');
	
			if (!button.hasClass('loading')) {
	
				button.addClass('loading');
	
				$.ajax({
					type: "POST",
					data: {
						project_id: project_id,
						nonce: motor_ajax_var.nonce,
						action: 'motor_project_quick_view'
					},
					url: motor_ajax_var.url,
					success: function(data){
						$(button).removeClass('loading');
						$.fancybox({
							content: data,
							padding: 0,
							helpers : {
								overlay : {
									locked  : false
								}
							}
						});
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$(button).remove();
						alert(jqXHR + " :: " + textStatus + " :: " + errorThrown);
					}
				});
			}
			return false;
		});


		// Sticky Header
		if ($('.header-sticky').length > 0) {
			$(window).scroll(function () {
				var topbar = false;
				var topbar_ht = $('.site-header').height();
				if ($('.site-header').length > 0 && $('.site-header').css('display') !== 'none') {
					topbar = true;
				}
				if (topbar) {
					$('body').css('margin-top', '0px');
					if (topbar_ht < $(window).scrollTop()) {
						$('.header-sticky .header').addClass('header_sticky');
						$('.site-header').css('margin-bottom', $('.header-sticky .header').outerHeight());
					} else {
						$('.header-sticky .header').removeClass('header_sticky');
						$('.site-header').css('margin-bottom', '0px');
					}
				} else {
					$('.header-sticky .header').addClass('header_sticky');
					$('body').css('margin-top', $('.header-sticky .header').outerHeight());
				}
			});
		}


        // Header Builder Sticky
        if ($('#site-header.site-header-sticky').length > 0) {
            $('#site-header.site-header-sticky').addClass('sticked');
            if (!$('#site-header.site-header-sticky').hasClass('site-header-overlay')) {
                $('body').css('margin-top', $('#site-header.site-header-sticky').outerHeight());
            }
            $(window).scroll(function () {
                $('#site-header.site-header-sticky').addClass('sticked');
                if (!$('#site-header.site-header-sticky').hasClass('site-header-overlay')) {
                    $('body').css('margin-top', $('#site-header.site-header-sticky').outerHeight());
                }
            });
        }


		// Images Carousel
		if ($('.images-carousel').length > 0) {
			$('.images-carousel').each(function () {
				var carousel = $(this);

				if (carousel.find('.swiper-button-next').length > 0) {
					var nextButton = '.swiper-button-next';
					var prevButton = '.swiper-button-prev';
				} else {
					var nextButton = '';
					var prevButton = '';
				}
				if (carousel.find('.swiper-pagination').length > 0) {
					var pagination = '.swiper-pagination';
				} else {
					var pagination = '';
				}
				if (carousel.find('.swiper-scrollbar').length > 0) {
					var scrollbar = '.swiper-scrollbar';
				} else {
					var scrollbar = '';
				}

				var slideClass = 'swiper-slide';

				var images_carousel = new Swiper(carousel, {
					roundLengths: true,
					loop: carousel.data('loop'),
					autoHeight: carousel.data('auto_height'),
					navigation: {
						nextEl: nextButton,
						prevEl: prevButton,
					},
					pagination: {
						el: pagination,
					},
					paginationType: carousel.data('pagination_type'),
					paginationClickable: true,
					scrollbar: {
						el: scrollbar,
					},
					scrollbarHide: carousel.data('scrollbar_hide'),
					scrollbarDraggable: carousel.data('scrollbar_draggable'),
					speed: carousel.data('speed'),
					autoplay: {
					delay: carousel.data('autoplay'),
					},
					autoplayStopOnLast: carousel.data('autoplay_stop_on_last'),
					autoplayDisableOnInteraction: carousel.data('autoplay_disable_on_interaction'),
					freeMode: carousel.data('free_mode'),
					freeModeMomentum: carousel.data('free_mode_momentum'),
					freeModeSticky: carousel.data('free_mode_sticky'),
					spaceBetween: carousel.data('space_between'),
					slidesPerView: carousel.data('slides_per_view'),
					slidesPerGroup: carousel.data('slides_per_group'),
					centeredSlides: carousel.data('centered_slides'),
					grabCursor: carousel.data('grab_cursor'),
					direction: carousel.data('direction'),
					mousewheelControl: carousel.data('mousewheel_control'),
					keyboardControl: carousel.data('keyboard_control'),
					effect: carousel.data('effect'),

					slideClass: slideClass
				});
			});
		}


		if ($('#product-pg-carousel').length) {
			var productCarousel = new Swiper('#product-pg-carousel', {
				spaceBetween: 10,
				slides_per_group: 1,
				slidesPerView: 'auto',
				centeredSlides: true,
				loop: true,
				/*navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                },*/
				navigation: false,
				pagination: false
			});
			var productCarouselThumbs = new Swiper('#product-pg-carousel-thumbs', {
				spaceBetween: 10,
				centeredSlides: true,
				slidesPerView: 10,
				touchRatio: 0.2,
				slideToClickedSlide: true,
				loop: true,
				navigation: false,
				pagination: false
			});
			productCarousel.controller.control = productCarouselThumbs;
			productCarouselThumbs.controller.control = productCarousel;
		}

		// Project Carousel
		if ($('#project-pg-slider').length) {
			var projectSlider = new Swiper('#project-pg-slider', {
				spaceBetween: 10,
				slides_per_group: 1,
				slidesPerView: 1,
				centeredSlides: false,
				loop: false,
				navigation: false,
				pagination: false,
				autoHeight: true,
			});
			var projectSliderThumbs = new Swiper('#project-pg-slider-thumbs', {
				spaceBetween: 10,
				centeredSlides: true,
				slidesPerView: 10,
				touchRatio: 0.2,
				slideToClickedSlide: true,
				loop: false,
				navigation: false,
				pagination: false,
				on: {
					click: function () {
						projectSlider.update();
					}
				}
			});
			projectSlider.controller.control = projectSliderThumbs;
			projectSliderThumbs.controller.control = projectSlider;
		}


		// Hotspots
		if ($('#hotspot-cont').length > 0) {
			for (var i = 1; i <= $('#hotspot-cont').data('lines-count'); i++) {
				if ($('#hotspot-cont .hotspot-res' + i + ' span').length > 0) {
					motor_create_line(
						($('#hotspot-cont .hotspot-res' + i + ' span').offset().left + 17),
						($('#hotspot-cont .hotspot-res' + i + ' span').offset().top + 9),
						($('#hotspot-cont .hotspot-point' + i).offset().left + 6),
						($('#hotspot-cont .hotspot-point' + i).offset().top + 6),
						('#hotspot-cont .hotspot-res' + i)
					);
				}
			}
			$(window).resize(function () {
				for (var i = 1; i <= $('#hotspot-cont').data('lines-count'); i++) {
					if ($('#hotspot-cont .hotspot-res' + i + ' span').length > 0) {
						$('#hotspot-cont .line').remove();
						for (var i = 1; i <= $('#hotspot-cont').data('lines-count'); i++) {
							motor_create_line(
								($('#hotspot-cont .hotspot-res' + i + ' span').offset().left + 17),
								($('#hotspot-cont .hotspot-res' + i + ' span').offset().top + 9),
								($('#hotspot-cont .hotspot-point' + i).offset().left + 6),
								($('#hotspot-cont .hotspot-point' + i).offset().top + 6),
								('#hotspot-cont .hotspot-res' + i)
							);
						}
					}
				}
			});
		}


		// Search
		$('.el-header-icon-search').on('click', function () {
			var $body = $('body');
			var $input = $('#main-searchform input[type=text]');
			if (!$body.hasClass('search-opened')) {
				$body.addClass('search-opened');
				$input.focus();
			} else {
				$body.removeClass('search-opened');
			}
			return false;
		});
		$('#main-searchform-close').on('click', function () {
			if ($('body').hasClass('search-opened')) {
				$('body').removeClass('search-opened');
			}
			return false;
		});
		$('html').on('click', 'body.search-opened', function () {
			$('body').removeClass('search-opened');
		});
		$('body').on('click', '.main-searchform form', function(event){
			event.stopPropagation();
		});

		
		$('.el-header-icon-search-products > a').on('click', function () {
			var $input = $(this).parent().find('input[type=search]');
			$input.focus();
			if ($('body').hasClass('search-show')) {
				$('body').removeClass('search-show');
			} else {
				$('body').addClass('search-show');
			}
			return false;
		});
		$('html').on('click', 'body.search-show', function (event) {
			if ($(event.target).parents('.el-header-icon-search-products').length) {
	
			} else {
				$('body').removeClass('search-show');
			}
		});


        if ($('.prod-catalog-carousel:not(.brazzers-daddy)').length > 0) {
            $('.prod-catalog-carousel:not(.brazzers-daddy)').brazzersCarousel();
        }
        $(document).on('woof_ajax_done', function () {
            if ($('.prod-catalog-carousel:not(.brazzers-daddy)').length > 0) {
                $('.prod-catalog-carousel:not(.brazzers-daddy)').brazzersCarousel();
            }
        });


        if (jQuery('.motor_product_categories').length > 0) {
            jQuery(".motor_product_categories").mThumbnailScroller({
                axis:"yx",
                type:"hover-precise"
            });
        }



	});
})(jQuery);
